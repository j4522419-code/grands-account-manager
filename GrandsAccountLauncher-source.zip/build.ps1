#Requires -Version 7.0
param([switch]$BrowserChecks, [string]$Dotnet = 'dotnet')
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$Dotnet = (Get-Command $Dotnet -ErrorAction Stop).Source
$env:DOTNET_ROOT = Split-Path -Parent $Dotnet
$env:DOTNET_CLI_TELEMETRY_OPTOUT = '1'
$env:DOTNET_NOLOGO = '1'
function Run-Dotnet {
    & $Dotnet @args
    if ($LASTEXITCODE -ne 0) { throw "dotnet $($args[0]) failed." }
}
New-Item -ItemType Directory -Path './release/app' -Force | Out-Null
Run-Dotnet restore tests/Launcher.Tests.csproj --locked-mode --packages ./packages --configfile NuGet.Config
Run-Dotnet build tests/Launcher.Tests.csproj -c Release --no-restore
$testArgs = @()
if ($BrowserChecks) { $testArgs += '--public-login' }
& ./tests/bin/Release/net10.0-windows/Launcher.Tests.exe @testArgs | Tee-Object ./release/test-results.txt
if ($LASTEXITCODE -ne 0) { throw 'Launcher tests failed.' }
Run-Dotnet publish GrandsAccountLauncher.csproj -c Release -r win-x64 --self-contained true -o ./release/app `
    '-p:PublishSingleFile=true' '-p:IncludeNativeLibrariesForSelfExtract=true' '-p:EnableCompressionInSingleFile=true' `
    '-p:DebugType=none' '-p:DebugSymbols=false' '-p:RestorePackagesPath=./packages' '-p:RestoreConfigFile=NuGet.Config' '-p:RestoreLockedMode=true'
$smoke = Start-Process -FilePath './release/app/GrandsAccountLauncher.exe' -ArgumentList '--smoke-test' -PassThru -WindowStyle Hidden
if (-not $smoke.WaitForExit(20000)) { Stop-Process -Id $smoke.Id; throw 'Published launcher startup timed out.' }
if ($smoke.ExitCode -ne 0) { throw 'Published launcher startup failed.' }
if ($BrowserChecks) {
    $browserSmoke = Start-Process -FilePath './release/app/GrandsAccountLauncher.exe' -ArgumentList '--browser-smoke-test' -PassThru -WindowStyle Hidden
    if (-not $browserSmoke.WaitForExit(25000)) { Stop-Process -Id $browserSmoke.Id; throw 'Published WebView2 startup timed out.' }
    if ($browserSmoke.ExitCode -ne 0) { throw 'Published WebView2 startup failed.' }
}
Remove-Item -LiteralPath './release/app/Microsoft.Web.WebView2.Core.xml','./release/app/Microsoft.Web.WebView2.WinForms.xml' -ErrorAction SilentlyContinue
Copy-Item -LiteralPath './README.md','./LICENSE','./TEST-RESULTS.md' -Destination './release/app' -Force
Copy-Item -LiteralPath './licenses' -Destination './release/app' -Recurse -Force
& ./scripts/package.ps1
Write-Output 'Done: release/GrandsAccountLauncher-win-x64.zip and release/GrandsAccountLauncher-source.zip'
