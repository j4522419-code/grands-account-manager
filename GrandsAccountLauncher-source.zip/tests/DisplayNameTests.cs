using System.Net;
using System.Text.Json;
using GrandsAccountLauncher;
using GrandsAccountLauncher.Roblox;
using GrandsAccountLauncher.Storage;

internal static partial class Tests
{
    private static async Task DisplayNames()
    {
        var requests = new Dictionary<string, int>();
        using var api = new RobloxApi(new Handler(request =>
        {
            var cookie = request.Headers.GetValues("Cookie").Single();
            var id = cookie.EndsWith("a") ? 101 : 202;
            if (request.Method == HttpMethod.Get)
                return new(HttpStatusCode.OK) { Content = new StringContent($"{{\"id\":{id},\"name\":\"Account_{id}\",\"displayName\":\"Old\"}}") };
            requests.TryGetValue(cookie, out var count); requests[cookie] = ++count;
            Check(request.Method == HttpMethod.Patch && request.RequestUri!.AbsolutePath == $"/v1/users/{id}/display-names", "display name request uses verified account identity");
            using var body = JsonDocument.Parse(request.Content!.ReadAsStringAsync().GetAwaiter().GetResult());
            Check(body.RootElement.GetProperty("newDisplayName").GetString() == "New Name", "display name body preserves spaces");
            if (count == 1)
            {
                Check(!request.Headers.Contains("x-csrf-token"), "display name starts with no shared CSRF");
                var response = new HttpResponseMessage(HttpStatusCode.Forbidden);
                response.Headers.Add("x-csrf-token", "csrf-" + id); return response;
            }
            Check(request.Headers.GetValues("x-csrf-token").Single() == "csrf-" + id, "display name CSRF belongs to this account");
            return new(HttpStatusCode.OK);
        }));
        var first = new Account { Username = "Account_101", Cookie = "a" };
        var second = new Account { Username = "Account_202", Cookie = "b" };
        await Task.WhenAll(api.SetDisplayNameAsync(first, "New Name"), api.SetDisplayNameAsync(second, "New Name"));
        Check(first.DisplayName == "New Name" && second.UserId == 202, "successful names and verified user IDs saved in memory");

        foreach (var scenario in new[] { "wrong account", "unchanged", "moderated", "limited", "expired", "cancelled" })
        {
            var patches = 0;
            using var client = new RobloxApi(new Handler(request =>
            {
                if (request.Method == HttpMethod.Get)
                    return scenario == "expired" ? new(HttpStatusCode.Unauthorized) : new(HttpStatusCode.OK)
                    { Content = new StringContent($"{{\"id\":42,\"name\":\"Example\",\"displayName\":\"{(scenario == "unchanged" ? "New" : "Old")}\"}}") };
                patches++;
                return new(scenario == "limited" ? HttpStatusCode.TooManyRequests : HttpStatusCode.BadRequest);
            }));
            var account = new Account { Username = "Example", UserId = scenario == "wrong account" ? 99 : 42, Cookie = "fixture", DisplayName = "Old" };
            using var cancellation = new CancellationTokenSource();
            if (scenario == "cancelled") cancellation.Cancel();
            try
            {
                await client.SetDisplayNameAsync(account, "New", cancellation.Token);
                Check(scenario == "unchanged", "unchanged names avoid write requests");
            }
            catch (Exception ex) when (ex is SessionExpiredException or InvalidOperationException or OperationCanceledException)
            { Check(scenario != "unchanged", "expected failure for " + scenario); }
            Check(patches == (scenario is "moderated" or "limited" ? 1 : 0), "no repeated or unauthorized name changes for " + scenario);
            Check(account.DisplayName == (scenario == "unchanged" ? "New" : "Old"), "failed change preserves saved display name for " + scenario);
        }
        var store = new AccountStore(Path.Combine(scratch, "display.gal"));
        store.Data.Accounts.Add(first);
        store.Data.LegacyData = new() { ["SignupDrafts"] = JsonSerializer.SerializeToElement(new[] { new { Username = "Old_Draft", Password = "old-secret" } }) };
        store.Save(); var loaded = new AccountStore(store.FilePath); loaded.Load(); loaded.Save();
        Check(loaded.Data.Accounts[0].DisplayName == "New Name", "display name survives encrypted save");
        Check(loaded.Data.LegacyData!["SignupDrafts"][0].GetProperty("Username").GetString() == "Old_Draft", "older encrypted data survives removal of creation feature");
        Check(!File.ReadAllText(store.FilePath).Contains("old-secret"), "legacy data remains encrypted");
    }
}
