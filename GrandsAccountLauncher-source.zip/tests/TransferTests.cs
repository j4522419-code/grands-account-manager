using System.Text.Json.Nodes;
using GrandsAccountLauncher;
using GrandsAccountLauncher.Storage;
using GrandsAccountLauncher.Ui;

internal static partial class Tests
{
    private static void Transfers()
    {
        var accounts = new List<Account>
        {
            new() { Username = "rgthgfe2343tgh", Password = " leading:secret, trailing ", Cookie = "cookie-one", UserId = 11, DisplayName = "First", LastGame = new(123) },
            new() { Username = "hugoboyyyyj", Password = "other-secret", Cookie = "cookie-two", UserId = 22 }
        };
        Check(AccountCopy.Format(accounts, CopyField.Username) == "rgthgfe2343tgh, hugoboyyyyj", "multiple usernames copied in row order with comma and space");
        Check(AccountCopy.Format(accounts, CopyField.Password) == " leading:secret, trailing , other-secret", "password copy preserves exact password characters");
        Check(AccountCopy.Format(accounts, CopyField.Cookie) == "cookie-one, cookie-two", "multiple cookies use requested separator");
        Check(AccountCopy.Format(accounts, CopyField.Combo) == "rgthgfe2343tgh: leading:secret, trailing , hugoboyyyyj:other-secret", "combo copy joins username password pairs");
        Check(AccountCopy.Format(accounts.Take(1), CopyField.Username) == accounts[0].Username, "single account copy has no added delimiter");
        foreach (var pin in new[] { "", "123", "12345", "abcd", "１２３４" })
            Throws<ArgumentException>(() => AccountTransfer.Encrypt(accounts, pin), "PIN requires exactly four ASCII digits");
        var encrypted = AccountTransfer.Encrypt(accounts, "0042");
        Check(!encrypted.Contains(accounts[0].Username) && !encrypted.Contains(accounts[0].Password) && !encrypted.Contains(accounts[0].Cookie), "export contains no plaintext credentials");
        var decoded = AccountTransfer.Decrypt(encrypted, "0042");
        Check(decoded.Count == 2 && decoded[0].Password == accounts[0].Password && decoded[1].Cookie == accounts[1].Cookie && decoded[0].LastGame?.PlaceId == 123,
            "correct PIN recovers complete accounts including exact credentials");
        Check(encrypted != AccountTransfer.Encrypt(accounts, "0042"), "same PIN gets fresh salt and nonce for every export");
        Throws<InvalidDataException>(() => AccountTransfer.Decrypt(encrypted, "0043"), "wrong PIN cannot return accounts");
        foreach (var field in new[] { "Salt", "Nonce", "Tag", "Data" })
        {
            var data = JsonNode.Parse(encrypted)!; var bytes = Convert.FromBase64String(data[field]!.GetValue<string>());
            bytes[0] ^= 1; data[field] = Convert.ToBase64String(bytes);
            Throws<InvalidDataException>(() => AccountTransfer.Decrypt(data.ToJsonString(), "0042"), "altered export rejected for " + field);
        }
        Throws<InvalidDataException>(() => AccountTransfer.Decrypt("not an export", "0042"), "ordinary text is not accepted as encrypted accounts");
        var path = Path.Combine(scratch, "export.txt"); AccountTransfer.Write(path, encrypted);
        Check(AccountTransfer.Decrypt(AccountTransfer.Read(path), "0042").Count == 2, "encrypted txt file round trip");
        Throws<InvalidDataException>(() => AccountTransfer.Write(Path.Combine(scratch, "export.gal"), encrypted), "export requires txt extension");
        var store = new AccountStore(Path.Combine(scratch, "imported.gal"));
        store.Data.Accounts.Add(new() { Username = accounts[0].Username.ToUpperInvariant(), Password = "existing", UserId = 11 });
        var added = store.ImportAccounts(decoded);
        Check(added.Count == 1 && store.Data.Accounts[0].Password == "existing" && added[0].Id != decoded[1].Id, "import skips duplicates and assigns fresh local IDs");
        var reload = new AccountStore(store.FilePath); reload.Load();
        Check(reload.Data.Accounts.Count == 2 && reload.Data.Accounts[1].Cookie == "cookie-two", "imported accounts saved with local Windows encryption");
        Check(store.ImportAccounts(decoded).Count == 0 && store.Data.Accounts.Count == 2, "repeated imports do not duplicate accounts");
        var broken = new AccountStore(scratch);
        Throws<IOException>(() => broken.ImportAccounts(accounts), "failed save reports import failure");
        Check(broken.Data.Accounts.Count == 0, "failed import save rolls back all added accounts");

        using var main = new MainForm(store, true); main.Show(); Application.DoEvents();
        var grid = FindGrid(main)!;
        grid.ClearSelection(); grid.Rows[0].Selected = grid.Rows[1].Selected = true;
        var raise = typeof(DataGridView).GetMethod("OnCellMouseDown", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic, null, [typeof(DataGridViewCellMouseEventArgs)], null)!;
        void RightClick(int row) => raise.Invoke(grid, [new DataGridViewCellMouseEventArgs(0, row, 2, 2, new MouseEventArgs(MouseButtons.Right, 1, 2, 2, 0))]);
        RightClick(0);
        Check(grid.SelectedRows.Count == 2, "right click on selected account preserves multiple selection");
        grid.ClearSelection(); grid.Rows[0].Selected = true; RightClick(1);
        Check(grid.SelectedRows.Count == 1 && grid.Rows[1].Selected, "right click on another account selects only that account");
        Check(grid.ContextMenuStrip!.Items.Cast<ToolStripItem>().Select(i => i.Text).SequenceEqual(new[] { "Copy username", "Copy password", "Copy cookie", "Copy combo" }), "right click menu contains all requested copy actions");
        main.Close();
    }
    private static DataGridView? FindGrid(Control root)
    {
        if (root is DataGridView grid) return grid;
        foreach (Control child in root.Controls) { var found = FindGrid(child); if (found is not null) return found; }
        return null;
    }
}


