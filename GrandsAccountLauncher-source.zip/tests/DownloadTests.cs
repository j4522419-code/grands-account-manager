using System.IO.Compression;
using System.Net;
using System.Security.Cryptography;
using GrandsAccountLauncher.Roblox;

internal static partial class Tests
{
    private static byte[] Package(params (string Name, string Text)[] files)
    {
        using var stream = new MemoryStream();
        using (var zip = new ZipArchive(stream, ZipArchiveMode.Create, true))
            foreach (var file in files) { var entry = zip.CreateEntry(file.Name); if (file.Name.EndsWith('/')) continue; using var writer = new StreamWriter(entry.Open()); writer.Write(file.Text); }
        return stream.ToArray();
    }
    private static async Task Downloads()
    {
        const string id = "version-1111111111111111";
        var history = VersionDownloads.ParseHistory($"New WindowsPlayer {id} at 9/2/2026 9:47:12 AM, file version: 0, 737, 0, 7371584\nNew WindowsPlayer version-hidden at 9/9/2026 1:00:00 PM, file version: 0, 738, 0, 1\nNew WindowsStudio {id} at 9/2/2026 9:47:12 AM, file version: 0, 737, 0, 7371584");
        Check(history.Count == 1 && history[0].Number == "0.737.0.7371584", "history only accepts downloadable Windows player IDs");
        var app = Package(("RobloxPlayerBeta.exe", "player fixture"));
        var fonts = Package(("/", ""), ("/font.txt", "font fixture"));
        string Manifest(byte[] player, string? hash = null) => $"v0\nRobloxApp.zip\n{hash ?? Convert.ToHexString(MD5.HashData(player))}\n{player.Length}\n1000\ncontent-fonts.zip\n{Convert.ToHexString(MD5.HashData(fonts))}\n{fonts.Length}\n1000\n";
        foreach (var scenario in new[] { "success", "corrupt", "traversal", "cancel", "missing" })
        {
            var root = Path.Combine(scratch, "download-" + scenario); var calls = 0;
            var payload = scenario == "traversal" ? Package(("../escaped.txt", "bad")) : app;
            using var client = new VersionDownloads(new Handler(request =>
            {
                calls++;
                Check(request.RequestUri!.Host == "setup.rbxcdn.com", "packages always use official Roblox host");
                if (scenario == "missing") return new(HttpStatusCode.NotFound);
                return new(HttpStatusCode.OK) { Content = request.RequestUri.AbsolutePath.EndsWith("rbxPkgManifest.txt")
                    ? new StringContent(Manifest(payload, scenario == "corrupt" ? new string('0', 32) : null))
                    : new ByteArrayContent(request.RequestUri.AbsolutePath.EndsWith("RobloxApp.zip") ? payload : fonts) };
            }));
            using var cancellation = new CancellationTokenSource();
            if (scenario == "cancel") cancellation.Cancel();
            try
            {
                var path = await client.DownloadAsync(id, root, null, cancellation.Token);
                Check(scenario == "success" && File.Exists(path) && File.Exists(Path.Combine(root, id, "content/fonts/font.txt")), "complete download assembles player and content folders");
                var previousCalls = calls;
                Check(await client.DownloadAsync(id, root, null, CancellationToken.None) == path && calls == previousCalls, "completed download reused without replacing it");
            }
            catch (Exception ex) when (ex is InvalidDataException or OperationCanceledException or InvalidOperationException)
            { Check(scenario != "success" && !Directory.Exists(Path.Combine(root, id)), "failed download never becomes installed for " + scenario); }
            Check(!Directory.GetDirectories(root).Any(d => Path.GetFileName(d).StartsWith(".partial-")), "partial download cleaned after " + scenario);
            Check(!File.Exists(Path.Combine(root, "escaped.txt")), "extraction cannot escape its folder");
        }
        Throws<InvalidDataException>(() => VersionDownloads.ParseManifest("v0\n../bad.zip\n" + new string('a', 32) + "\n10\n10"), "unsupported package paths rejected");
        using var checkClient = new VersionDownloads(new Handler(_ => throw new Exception("Unexpected request")));
        try { await checkClient.DownloadAsync("../bad", scratch, null, CancellationToken.None); throw new Exception("Bad ID accepted"); }
        catch (ArgumentException) { Check(true, "version path injection rejected before download"); }
    }

    private static async Task DownloadProbe()
    {
        using var client = new VersionDownloads();
        var history = await client.HistoryAsync(CancellationToken.None);
        var previous = history.DistinctBy(v => v.Number).Skip(1).First();
        var root = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "../../../../release/download-probe"));
        var last = -1;
        var path = await client.DownloadAsync(previous.Id, root, new Progress<DownloadProgress>(p =>
        { if (p.Percent / 10 != last) { last = p.Percent / 10; Console.WriteLine($"Download {p.Percent} percent"); } }), CancellationToken.None);
        Check(File.Exists(path) && File.Exists(Path.Combine(Path.GetDirectoryName(path)!, "AppSettings.xml")), "real previous Roblox build downloaded and assembled without launching it");
        Console.WriteLine(previous);
        Console.WriteLine(path);
    }
}


