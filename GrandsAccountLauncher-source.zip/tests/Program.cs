using System.Diagnostics;
using System.Net;
using System.Security.Cryptography;
using System.Text.Json.Nodes;
using GrandsAccountLauncher;
using GrandsAccountLauncher.Roblox;
using GrandsAccountLauncher.Storage;
using GrandsAccountLauncher.Ui;
using Microsoft.Web.WebView2.WinForms;

internal static partial class Tests
{
    private static int count;
    private static string scratch = "";
    [STAThread]
    private static int Main(string[] args)
    {
        Application.SetHighDpiMode(HighDpiMode.PerMonitorV2); Application.EnableVisualStyles();
        if (args.FirstOrDefault()?.StartsWith("roblox-player:") == true)
        {
            using var player = new Form { Text = "Launcher test player", ShowInTaskbar = true,
                StartPosition = FormStartPosition.Manual, Location = new(-2000, -2000) };
            Application.Run(player); return 0;
        }
        scratch = Path.Combine(Path.GetTempPath(), "GrandsLauncherTests", Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(scratch);
        var exit = 0;
        using var host = new Form { ShowInTaskbar = false, Opacity = 0 };
        host.Shown += async (_, _) =>
        {
            try
            {
                if (args.Contains("--download-probe")) { await DownloadProbe(); return; }
                if (args.Contains("--preview-dialogs")) { Dialogs(); return; }
                Import(); Targets(); Storage(); Transfers(); ClientVersions(); await Downloads(); await DisplayNames(); MutexOwnership(); await Api(); await Processes(); Dialogs();
                if (args.Contains("--browser") || args.Contains("--public-login"))
                {
                    await Browser(host, args.Contains("--public-login"));
                }
                Console.WriteLine($"PASS: {count} assertions. No live accounts changed or taskkill command executed.");
            }
            catch (Exception ex) { Console.WriteLine("FAIL: " + ex); exit = 1; }
            finally { host.Close(); }
        };
        Application.Run(host);
        // Only the uniquely-created test directory can be removed here.
        if (scratch.StartsWith(Path.Combine(Path.GetTempPath(), "GrandsLauncherTests") + Path.DirectorySeparatorChar))
        { try { Directory.Delete(scratch, true); } catch (IOException) { } }
        return exit;
    }
    private static void Check(bool value, string label)
    { if (!value) throw new Exception(label); count++; Console.WriteLine("PASS " + label); }
    private static void Throws<T>(Action action, string label) where T : Exception
    { try { action(); } catch (T) { Check(true, label); return; } throw new Exception("Expected " + typeof(T).Name + ": " + label); }

    private static void Import()
    {
        var result = AccountImport.Parse(" Alpha_One: leading:colon:trailing \r\nBeta_Two:pass\n\nalpha_one:duplicate\rGamma_Three:third", ["BETA_TWO"]);
        Check(result.Accounts.Count == 2 && result.Duplicates == 2 && result.Errors.Count == 0, "bulk mixed line endings and case-insensitive duplicate detection");
        Check(result.Accounts[0].Password == " leading:colon:trailing ", "password punctuation and whitespace preserved exactly");
        var invalid = AccountImport.Parse("no separator\nabc:\n:password\nbad name:pass\nvalid_name:secret", []);
        Check(invalid.Errors.Count == 4 && invalid.Accounts.Count == 1, "invalid import rows reported without losing valid rows");
        Check(invalid.Errors.All(e => !e.Contains("secret") && !e.Contains("password\n")), "import errors do not echo credentials");
    }
    private static void Targets()
    {
        Check(GameInput.Parse("12345").PlaceId == 12345, "numeric place ID");
        Check(GameInput.Parse("https://www.roblox.com/games/12345/Example").PlaceId == 12345, "official game link");
        foreach (var invalid in new[] { "0", "-1", "9999999999999999999999", "https://evil.test/games/123", "https://roblox.com.evil.test/games/123", "http://roblox.com/games/123", "https://www.roblox.com/share?code=test&type=Server" })
            Throws<ArgumentException>(() => GameInput.Parse(invalid), "reject unsupported game input: " + invalid);
        Throws<ArgumentException>(() => GameInput.Parse("123", "bad-job"), "reject malformed server ID");
        var target = GameInput.Parse("123", "11111111-2222-3333-4444-555555555555");
        var protocol = ClientLauncher.BuildProtocol("ticket+unsafe:value", target);
        Check(protocol.Contains("ticket%2Bunsafe%3Avalue"), "ticket protocol characters are encoded");
        var decoded = Uri.UnescapeDataString(protocol);
        Check(decoded.Contains("RequestGameJob") && decoded.Contains("gameId=" + target.JobId), "specific-server rejoin target preserved");
        Check(Uri.UnescapeDataString(ClientLauncher.BuildProtocol("ticket", new(123))).Contains("request=RequestGame&"), "normal game target requests matchmaking");
    }
    private static void Storage()
    {
        var path = Path.Combine(scratch, "accounts.gal"); var store = new AccountStore(path);
        store.Data.Accounts.Add(new() { Username = "Test_Account", Password = "unique-secret-password", Cookie = "unique-session-value", LastGame = new(123) });
        store.Save(); var original = File.ReadAllText(path);
        Check(!original.Contains("Test_Account") && !original.Contains("unique-secret") && !original.Contains("unique-session"), "encrypted file contains no plaintext credentials or account names");
        var loaded = new AccountStore(path); loaded.Load();
        Check(loaded.Data.Accounts[0].Password == "unique-secret-password" && loaded.Data.Accounts[0].LastGame?.PlaceId == 123, "automatic Windows decryption round-trip including last game");
        store.Save(); Check(original != File.ReadAllText(path), "fresh key and nonce on each save");
        Check(File.ReadAllText(path + ".bak") == original, "atomic replace retains previous encrypted version");
        foreach (var field in new[] { "Cipher", "Tag", "Nonce", "Key" })
        {
            var json = JsonNode.Parse(original)!; var data = Convert.FromBase64String(json[field]!.GetValue<string>());
            data[data.Length / 2] ^= 64; json[field] = Convert.ToBase64String(data); File.WriteAllText(path, json.ToJsonString());
            Throws<CryptographicException>(() => new AccountStore(path).Load(), "tampering rejected: " + field);
            Check(File.ReadAllText(path) == json.ToJsonString(), "failed load does not overwrite file: " + field);
        }
        File.WriteAllText(path, original);
        var reloaded = new AccountStore(path); reloaded.Load(); Check(reloaded.Data.Accounts.Count == 1, "original encrypted file remains recoverable");
    }
    private static void ClientVersions()
    {
        var root = Path.Combine(scratch, "versions");
        var one = Path.Combine(root, "version-one", "RobloxPlayerBeta.exe");
        var two = Path.Combine(root, "version-two", "RobloxPlayerBeta.exe");
        Directory.CreateDirectory(Path.GetDirectoryName(one)!); Directory.CreateDirectory(Path.GetDirectoryName(two)!);
        File.WriteAllText(one, "fixture"); File.WriteAllText(two, "fixture");
        File.SetLastWriteTimeUtc(one, DateTime.UtcNow.AddDays(-1));
        var choices = ClientLauncher.InstalledClients([root, root]);
        Check(choices.Count == 2 && choices[0] == two, "installed versions sorted and duplicates removed");
        Check(ClientLauncher.FindClient(one) == one, "explicit older version wins over newer installed version");
        File.Delete(one);
        Throws<InvalidOperationException>(() => ClientLauncher.FindClient(one), "missing selected version never falls back silently");
        Throws<InvalidOperationException>(() => ClientLauncher.FindClient("RobloxPlayerBeta.exe"), "relative client paths rejected");
        var store = new AccountStore(Path.Combine(scratch, "version.gal"));
        store.Data.RobloxClientPath = two; store.Save();
        var loaded = new AccountStore(store.FilePath); loaded.Load();
        Check(loaded.Data.RobloxClientPath == two, "global client selection survives encrypted save");
        Check(new LauncherData().RobloxClientPath == "", "older account files default to automatic version");
    }

    private static void MutexOwnership()
    {
        var name = "Local\\GrandsTest_" + Guid.NewGuid().ToString("N");
        using (var first = new MultiInstance(name, false))
        {
            first.EnsureEnabled(); Check(first.Enabled, "dedicated thread owns multi-instance mutex");
            using var second = new MultiInstance(name, false);
            Throws<InvalidOperationException>(second.EnsureEnabled, "existing mutex is reported as conflict, not false success");
            Check(!second.Enabled, "conflicting manager stays disabled");
        }
        using var replacement = new MultiInstance(name, false);
        replacement.EnsureEnabled(); Check(replacement.Enabled, "mutex cleanly released and reacquired");
    }
    private static async Task Api()
    {
        var attempts = new Dictionary<string, int>();
        using var api = new RobloxApi(new Handler(request =>
        {
            var cookie = request.Headers.GetValues("Cookie").Single();
            attempts.TryGetValue(cookie, out var attempt); attempts[cookie] = ++attempt;
            if (attempt == 1)
            {
                Check(!request.Headers.Contains("x-csrf-token"), "CSRF starts without shared token");
                var challenge = new HttpResponseMessage(HttpStatusCode.Forbidden); challenge.Headers.Add("x-csrf-token", "csrf-" + cookie); return challenge;
            }
            Check(request.Headers.GetValues("x-csrf-token").Single() == "csrf-" + cookie, "CSRF retry bound to correct account");
            var result = new HttpResponseMessage(HttpStatusCode.OK); result.Headers.Add("rbx-authentication-ticket", "ticket-" + cookie); return result;
        }));
        var tickets = await Task.WhenAll(api.GetTicketAsync("account-a"), api.GetTicketAsync("account-b"));
        Check(tickets[0] != tickets[1], "independent account tickets");
        using var expired = new RobloxApi(new Handler(_ => new(HttpStatusCode.Unauthorized)));
        try { await expired.GetUserAsync("expired"); throw new Exception("No session error"); }
        catch (SessionExpiredException) { Check(true, "expired session triggers sign-in path"); }
        using var limited = new RobloxApi(new Handler(_ => new(HttpStatusCode.TooManyRequests)));
        try { await limited.GetTicketAsync("limited"); throw new Exception("No rate-limit error"); }
        catch (InvalidOperationException e) { Check(e.Message.Contains("rate-limiting"), "rate limits stop retries with useful status"); }
    }
    private static async Task Processes()
    {
        using var launcher = new ClientLauncher(); var first = new Account(); var second = new Account();
        var client = Path.Combine(AppContext.BaseDirectory, "Launcher.Tests.exe");
        try
        {
            await launcher.LaunchAsync(first, new(100), client, "fixture-ticket", CancellationToken.None);
            await launcher.LaunchAsync(second, new(200), client, "fixture-ticket", CancellationToken.None);
            var firstPid = launcher.ProcessId(first.Id); var secondPid = launcher.ProcessId(second.Id);
            Check(firstPid.HasValue && secondPid.HasValue && firstPid != secondPid, "two independent player processes tracked per account");
            Check(first.LastGame?.PlaceId == 100 && second.LastGame?.PlaceId == 200, "last game saved independently after player window opens");
            try { await launcher.LaunchAsync(first, new(300), client, "fixture-ticket", CancellationToken.None); throw new Exception("Duplicate allowed"); }
            catch (InvalidOperationException) { Check(true, "duplicate launch rejected for running account"); }
            await launcher.StopAsync(first.Id);
            Check(launcher.ProcessId(first.Id) is null && launcher.ProcessId(second.Id) == secondPid, "stop only closes selected account process");
            await launcher.LaunchAsync(first, first.LastGame!, client, "new-fixture-ticket", CancellationToken.None);
            Check(launcher.ProcessId(first.Id) != firstPid && first.LastGame!.PlaceId == 100, "relaunch uses saved game and new process while other account stays running");
            using var cancelled = new CancellationTokenSource(); cancelled.Cancel();
            try { await launcher.StopAsync(second.Id, cancelled.Token); throw new Exception("Cancelled stop was accepted"); }
            catch (OperationCanceledException) { Check(launcher.ProcessId(second.Id) == secondPid, "cancelled stop preserves the running player"); }
            var third = new Account();
            try { await launcher.LaunchAsync(third, new(300), client, "fixture-ticket", cancelled.Token); }
            catch (OperationCanceledException) { Check(launcher.ProcessId(third.Id) is null, "cancelled launch creates no player process"); }
        }
        finally { await launcher.StopAsync(first.Id); await launcher.StopAsync(second.Id); }
    }
    private static void Dialogs()
    {
        using var account = new AccountForm(); using var bulk = new BulkImportForm([]);
        using var main = new MainForm(new AccountStore(Path.Combine(scratch, "ui.gal")), true);
        using var display = new DisplayNamesForm(3); using var versions = new ClientVersionForm(""); using var previous = new PreviousVersionsForm(true); using var pin = new PinForm(true, 2);
        Check(account.Controls.Count > 0 && bulk.Controls.Count > 0 && main.Controls.Count > 0, "main, account, and bulk dialogs construct without vault unlock");
        foreach (var (form, name) in new[] { ((Form)account, "account"), (bulk, "bulk"), (display, "display"), (versions, "versions"), (previous, "previous"), (pin, "pin") })
        {
            form.Show(); form.PerformLayout();
            using var bitmap = new Bitmap(form.Width, form.Height); form.DrawToBitmap(bitmap, new(Point.Empty, form.Size));
            var folder = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "../../../../release")); Directory.CreateDirectory(folder);
            bitmap.Save(Path.Combine(folder, name + "-preview.png")); form.Close();
        }
    }
    private static async Task Browser(Form host, bool publicLogin)
    {
        using var browser = new WebView2 { Dock = DockStyle.Fill, CreationProperties = new()
            { UserDataFolder = Path.Combine(scratch, "browser"), ProfileName = "TestProfile", IsInPrivateModeEnabled = true } };
        host.Controls.Add(browser);
        await browser.EnsureCoreWebView2Async().WaitAsync(TimeSpan.FromSeconds(25));
        Check(browser.CoreWebView2.Profile.IsInPrivateModeEnabled, "installed WebView2 initializes isolated InPrivate profile");
        browser.CoreWebView2.Settings.IsPasswordAutosaveEnabled = false;
        browser.CoreWebView2.Settings.IsGeneralAutofillEnabled = false;
        Check(!browser.CoreWebView2.Settings.IsPasswordAutosaveEnabled, "browser password persistence disabled");
        if (publicLogin)
        {
            var loaded = new TaskCompletionSource<bool>();
            browser.CoreWebView2.NavigationCompleted += (_, e) => loaded.TrySetResult(e.IsSuccess);
            browser.CoreWebView2.Navigate("https://www.roblox.com/login");
            Check(await loaded.Task.WaitAsync(TimeSpan.FromSeconds(40)), "public Roblox login page loads in WebView2");
            var found = false;
            for (var i = 0; i < 20; i++)
            {
                found = await browser.CoreWebView2.ExecuteScriptAsync("Boolean(document.querySelector('#login-username') && document.querySelector('#login-password') && document.querySelector('#login-button'))") == "true";
                if (found) break;
                await Task.Delay(500);
            }
            Check(found, "public Roblox page exposes all three login controls used by autofill; no credentials submitted");
        }
    }
    private sealed class Handler(Func<HttpRequestMessage, HttpResponseMessage> send) : HttpMessageHandler
    { protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken token) => Task.FromResult(send(request)); }
}




