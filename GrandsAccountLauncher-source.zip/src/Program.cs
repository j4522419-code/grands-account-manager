using GrandsAccountLauncher.Storage;
using GrandsAccountLauncher.Ui;
using Microsoft.Web.WebView2.WinForms;

namespace GrandsAccountLauncher;

internal static class Program
{
    [STAThread]
    private static int Main(string[] args)
    {
        Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        var preview = args.Length == 2 && args[0] == "--preview";
        var browserSmoke = args.Length == 1 && args[0] == "--browser-smoke-test";
        var smoke = browserSmoke || (args.Length == 1 && args[0] == "--smoke-test");
        var diagnosticResult = 0;
        using var single = new Mutex(true, "Local\\GrandsAccountLauncher_v3", out var first);
        if (!first && !preview && !smoke)
        { MessageBox.Show("Grands Account Launcher is already running", "Grands Account Launcher"); return 1; }
        try
        {
            var store = new AccountStore();
            if (!preview && !smoke) store.Load();
            if (preview)
            {
                store.Data.Accounts.AddRange([
                    new() { Username = "Grand_Main", Status = "Session saved", LastGame = new(920587237), LastLaunchUtc = DateTime.UtcNow.AddMinutes(-12) },
                    new() { Username = "Grand_Second", Status = "Session saved", LastGame = new(2753915549), LastLaunchUtc = DateTime.UtcNow.AddHours(-1) },
                    new() { Username = "Grand_Third", Status = "Needs sign-in" }
                ]);
                store.Data.LastGameInput = "https://www.roblox.com/games/920587237";
            }
            using var form = new MainForm(store, preview || smoke);
            if (preview || smoke)
            {
                form.Shown += (_, _) =>
                {
                    form.BeginInvoke(async () =>
                    {
                        try
                        {
                            if (preview)
                            {
                                using var bitmap = new Bitmap(form.Width, form.Height);
                                form.DrawToBitmap(bitmap, new(Point.Empty, form.Size));
                                bitmap.Save(Path.GetFullPath(args[1]), System.Drawing.Imaging.ImageFormat.Png);
                            }
                            if (browserSmoke)
                            {
                                var folder = Path.Combine(Path.GetTempPath(), "GrandsBrowserSmoke_" + Guid.NewGuid().ToString("N"));
                                using (var browser = new WebView2 { Dock = DockStyle.Fill, CreationProperties = new()
                                    { UserDataFolder = folder, ProfileName = "Smoke", IsInPrivateModeEnabled = true } })
                                {
                                    form.Controls.Add(browser);
                                    await browser.EnsureCoreWebView2Async().WaitAsync(TimeSpan.FromSeconds(15));
                                    if (!browser.CoreWebView2.Profile.IsInPrivateModeEnabled) diagnosticResult = 3;
                                }
                                // This uniquely generated diagnostic folder contains no account data.
                                try { Directory.Delete(folder, true); } catch (IOException) { } catch (UnauthorizedAccessException) { }
                            }
                        }
                        catch (Exception) { diagnosticResult = 3; }
                        finally { form.Close(); }
                    });
                };
            }
            Application.Run(form);
            return diagnosticResult;
        }
        catch (Exception ex)
        {
            if (!smoke && !preview) MessageBox.Show("Could not open the launcher\n" + Theme.Plain(ex.Message) + "\n\nYour encrypted accounts are in\n" + AccountStore.DataDirectory, "Grands Account Launcher", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return 2;
        }
        finally { if (first) single.ReleaseMutex(); }
    }
}

