using System.Text.Json.Serialization;

namespace GrandsAccountLauncher;

public sealed class Account
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Username { get; set; } = "";
    public string DisplayName { get; set; } = "";
    public string Password { get; set; } = "";
    public string Cookie { get; set; } = "";
    public long UserId { get; set; }
    public GameTarget? LastGame { get; set; }
    public DateTime? LastLaunchUtc { get; set; }
    [JsonIgnore] public string Status { get; set; } = "Not signed in";
}

public sealed record GameTarget(long PlaceId, string? JobId = null)
{
    public string Description => JobId is null ? PlaceId.ToString() : $"{PlaceId} · specific server";
}

public sealed class LauncherData
{
    public int Version { get; set; } = 3;
    public List<Account> Accounts { get; set; } = [];
    [JsonExtensionData] public Dictionary<string, System.Text.Json.JsonElement>? LegacyData { get; set; }
    public string LastGameInput { get; set; } = "";
}

public sealed record Credentials(string Username, string Password);
public sealed record ImportResult(List<Credentials> Accounts, List<string> Errors, int Duplicates);

public static class AccountImport
{
    public static ImportResult Parse(string text, IEnumerable<string> existing)
    {
        var seen = new HashSet<string>(existing, StringComparer.OrdinalIgnoreCase);
        var accounts = new List<Credentials>();
        var errors = new List<string>();
        var duplicates = 0;
        var lines = text.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
        for (var i = 0; i < lines.Length; i++)
        {
            var line = lines[i];
            if (string.IsNullOrWhiteSpace(line)) continue;
            var colon = line.IndexOf(':');
            if (colon < 1) { errors.Add($"Line {i + 1}: use username:password."); continue; }
            var user = line[..colon].Trim();
            var pass = line[(colon + 1)..]; // Preserve colons and whitespace in passwords exactly.
            if (!IsUsername(user) || pass.Length == 0)
            { errors.Add($"Line {i + 1}: enter a Roblox username and a nonempty password."); continue; }
            if (!seen.Add(user)) { duplicates++; continue; }
            accounts.Add(new(user, pass));
        }
        return new(accounts, errors, duplicates);
    }

    public static bool IsUsername(string value) => value.Length is >= 3 and <= 20 &&
        value.All(c => char.IsAsciiLetterOrDigit(c) || c == '_');
}

public static class GameInput
{
    public static GameTarget Parse(string input, string? job = null)
    {
        var text = input.Trim();
        string? place = text;
        if (Uri.TryCreate(text, UriKind.Absolute, out var uri))
        {
            if (uri.Scheme != "https" || !(uri.Host.Equals("roblox.com", StringComparison.OrdinalIgnoreCase) ||
                uri.Host.Equals("www.roblox.com", StringComparison.OrdinalIgnoreCase)))
                throw new ArgumentException("Use a numeric place ID or an https://www.roblox.com/games/... link.");
            if (!string.IsNullOrEmpty(uri.Query))
                throw new ArgumentException("Use the normal game link without share or private-server parameters. You can enter a server Job ID below.");
            var parts = uri.AbsolutePath.Split('/', StringSplitOptions.RemoveEmptyEntries);
            place = parts.Length >= 2 && parts[0].Equals("games", StringComparison.OrdinalIgnoreCase) ? parts[1] : null;
        }
        if (place is null || !place.All(char.IsAsciiDigit) || !long.TryParse(place, out var id) || id <= 0)
            throw new ArgumentException("Enter a positive numeric place ID or a Roblox /games/ link.");
        job = string.IsNullOrWhiteSpace(job) ? null : job.Trim();
        if (job is not null && !Guid.TryParseExact(job, "D", out _))
            throw new ArgumentException("A server Job ID must be a full UUID (xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx).");
        return new(id, job);
    }
}
