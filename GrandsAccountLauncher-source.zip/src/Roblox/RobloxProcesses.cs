using System.Diagnostics;

namespace GrandsAccountLauncher.Roblox;

public static class RobloxProcesses
{
    // Fixed command explicitly requested by the user. Never accepts account data or user-provided arguments.
    internal static ProcessStartInfo CloseAllCommand() => new(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "cmd.exe"))
    {
        Arguments = "/c taskkill /F /IM RobloxPlayerBeta.exe /T",
        UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true
    };
    public static async Task CloseAllAsync()
    {
        using var process = Process.Start(CloseAllCommand()) ?? throw new InvalidOperationException("Could not start taskkill.");
        var output = process.StandardOutput.ReadToEndAsync();
        var error = process.StandardError.ReadToEndAsync();
        await process.WaitForExitAsync(); await output; await error;
        var remaining = Process.GetProcessesByName("RobloxPlayerBeta");
        try
        {
            if (remaining.Length > 0) throw new InvalidOperationException("Some Roblox players could not be closed. Check their Windows permissions and try again.");
            if (process.ExitCode is not (0 or 128)) throw new InvalidOperationException($"taskkill exited with code {process.ExitCode}.");
        }
        finally { foreach (var player in remaining) player.Dispose(); }
    }
}
