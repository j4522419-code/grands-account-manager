namespace GrandsAccountLauncher.Roblox;
internal sealed class InactivityWatchdog(DateTimeOffset now)
{
    private DateTimeOffset lastProgress = now;
    private string? marker;
    public void Touch(DateTimeOffset now) => lastProgress = now;
    public bool Tick(DateTimeOffset now, string progress, bool waitingForUser)
    {
        if (marker != progress || waitingForUser) { marker = progress; lastProgress = now; return false; }
        if (now - lastProgress < TimeSpan.FromSeconds(10)) return false;
        lastProgress = now; return true;
    }
}

