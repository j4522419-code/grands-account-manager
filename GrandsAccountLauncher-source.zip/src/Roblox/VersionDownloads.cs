using System.Globalization;
using System.IO.Compression;
using System.Net;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using GrandsAccountLauncher.Storage;

namespace GrandsAccountLauncher.Roblox;

internal sealed record RemoteVersion(string Id, string Number, DateTime Date)
{
    public override string ToString() => $"{Number}   {Date:dd MMM yyyy}   {Id}";
}
internal sealed record ClientPackage(string Name, string Hash, long Size, long Expanded);
internal sealed record DownloadProgress(int Percent, string Message);

internal sealed class VersionDownloads : IDisposable
{
    public static string InstallRoot => Path.Combine(AccountStore.DataDirectory, "Versions");
    private readonly HttpClient http;
    private static readonly Regex VersionId = new("^version-[a-f0-9]{16}$", RegexOptions.CultureInvariant);
    private static readonly Dictionary<string, string> Folders = new(StringComparer.OrdinalIgnoreCase)
    {
        ["RobloxApp.zip"] = "", ["Libraries.zip"] = "", ["WebView2.zip"] = "",
        ["WebView2RuntimeInstaller.zip"] = "WebView2RuntimeInstaller", ["shaders.zip"] = "shaders", ["ssl.zip"] = "ssl",
        ["content-avatar.zip"] = "content/avatar", ["content-configs.zip"] = "content/configs",
        ["content-fonts.zip"] = "content/fonts", ["content-models.zip"] = "content/models",
        ["content-sky.zip"] = "content/sky", ["content-sounds.zip"] = "content/sounds",
        ["content-textures.zip"] = "content/textures", ["content-textures2.zip"] = "content/textures",
        ["content-textures3.zip"] = "PlatformContent/pc/textures", ["content-terrain.zip"] = "PlatformContent/pc/terrain",
        ["content-platform-fonts.zip"] = "PlatformContent/pc/fonts", ["content-platform-dictionaries.zip"] = "PlatformContent/pc/shared_compression_dictionaries",
        ["extracontent-places.zip"] = "ExtraContent/places", ["extracontent-luapackages.zip"] = "ExtraContent/LuaPackages",
        ["extracontent-translations.zip"] = "ExtraContent/translations", ["extracontent-models.zip"] = "ExtraContent/models",
        ["extracontent-textures.zip"] = "ExtraContent/textures"
    };
    public VersionDownloads(HttpMessageHandler? handler = null)
    {
        http = new(handler ?? new HttpClientHandler { AllowAutoRedirect = false, UseCookies = false }) { Timeout = TimeSpan.FromMinutes(15) };
    }

    public static List<RemoteVersion> ParseHistory(string text)
    {
        var result = new List<RemoteVersion>();
        foreach (Match match in Regex.Matches(text,
            @"New WindowsPlayer (version-[a-f0-9]{16}) at (.+?), file version:\s*(\d+),\s*(\d+),\s*(\d+),\s*(\d+)", RegexOptions.CultureInvariant))
        {
            if (!DateTime.TryParse(match.Groups[2].Value, CultureInfo.GetCultureInfo("en-US"), DateTimeStyles.None, out var date)) continue;
            result.Add(new(match.Groups[1].Value, string.Join('.', Enumerable.Range(3, 4).Select(i => match.Groups[i].Value)), date));
        }
        return result.OrderByDescending(v => v.Date).DistinctBy(v => v.Id).ToList();
    }

    public async Task<List<RemoteVersion>> HistoryAsync(CancellationToken token)
    {
        var versions = new List<RemoteVersion>();
        // Archive metadata supplies IDs omitted from the public history. It never supplies executable URLs.
        foreach (var url in new[] { "https://setup-rbxcdn.github.io/DeployHistory.txt", "https://setup.rbxcdn.com/DeployHistory.txt" })
        {
            token.ThrowIfCancellationRequested();
            try
            {
                using var timeout = CancellationTokenSource.CreateLinkedTokenSource(token); timeout.CancelAfter(TimeSpan.FromSeconds(30));
                using var response = await http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, timeout.Token);
                response.EnsureSuccessStatusCode();
                var bytes = await ReadBoundedAsync(response, 8_000_000, timeout.Token);
                versions.AddRange(ParseHistory(System.Text.Encoding.UTF8.GetString(bytes)));
            }
            catch (Exception ex) when (!token.IsCancellationRequested && ex is HttpRequestException or IOException or OperationCanceledException) { }
        }
        if (versions.Count == 0) throw new InvalidOperationException("Could not load previous versions   Try again");
        return versions.OrderByDescending(v => v.Date).DistinctBy(v => v.Id).ToList();
    }

    public static List<ClientPackage> ParseManifest(string text)
    {
        var lines = text.Replace("\r", "").Trim().Split('\n').Select(s => s.Trim()).ToArray();
        if (lines.Length < 5 || lines[0] != "v0" || (lines.Length - 1) % 4 != 0) throw new InvalidDataException("Invalid Roblox package list");
        var result = new List<ClientPackage>();
        for (var i = 1; i < lines.Length; i += 4)
        {
            var name = lines[i];
            if ((!Folders.ContainsKey(name) && name != "RobloxPlayerInstaller.exe") ||
                !Regex.IsMatch(lines[i + 1], "^[a-fA-F0-9]{32}$") ||
                !long.TryParse(lines[i + 2], out var size) || size is <= 0 or > 1_000_000_000 ||
                !long.TryParse(lines[i + 3], out var expanded) || expanded is < 0 or > 4_000_000_000)
                throw new InvalidDataException("This version uses an unsupported package layout");
            result.Add(new(name, lines[i + 1], size, expanded));
        }
        if (result.Select(p => p.Name).Distinct(StringComparer.OrdinalIgnoreCase).Count() != result.Count ||
            !result.Any(p => p.Name == "RobloxApp.zip") || result.Sum(p => p.Size) > 3_000_000_000 || result.Sum(p => p.Expanded) > 8_000_000_000)
            throw new InvalidDataException("Invalid Roblox package list");
        return result;
    }

    public async Task<string> DownloadAsync(string version, string root, IProgress<DownloadProgress>? progress, CancellationToken token)
    {
        if (!VersionId.IsMatch(version)) throw new ArgumentException("Choose a valid Roblox version");
        root = Path.GetFullPath(root);
        Directory.CreateDirectory(root);
        if ((File.GetAttributes(root) & FileAttributes.ReparsePoint) != 0) throw new IOException("Choose a normal folder for Roblox versions");
        var target = Path.Combine(root, version);
        if (Directory.Exists(target))
        {
            if (File.Exists(Path.Combine(target, "download.complete"))) return ClientLauncher.FindClient(Path.Combine(target, "RobloxPlayerBeta.exe"));
            throw new IOException("An incomplete folder already exists for this version");
        }
        progress?.Report(new(0, "Checking version"));
        using var manifestResponse = await http.GetAsync($"https://setup.rbxcdn.com/{version}-rbxPkgManifest.txt", HttpCompletionOption.ResponseHeadersRead, token);
        if (manifestResponse.StatusCode is HttpStatusCode.Forbidden or HttpStatusCode.NotFound)
            throw new InvalidOperationException("Roblox no longer provides this version   Choose another");
        manifestResponse.EnsureSuccessStatusCode();
        var packages = ParseManifest(System.Text.Encoding.UTF8.GetString(await ReadBoundedAsync(manifestResponse, 100_000, token)));
        var staging = Path.Combine(root, ".partial-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(staging);
        try
        {
            var total = packages.Sum(p => p.Size); long completed = 0;
            foreach (var package in packages)
            {
                token.ThrowIfCancellationRequested();
                var archive = Path.Combine(staging, ".package");
                using (var response = await http.GetAsync($"https://setup.rbxcdn.com/{version}-{package.Name}", HttpCompletionOption.ResponseHeadersRead, token))
                {
                    response.EnsureSuccessStatusCode();
                    if (response.Content.Headers.ContentLength is long length && length != package.Size) throw new InvalidDataException("Download size does not match Roblox");
                    await using var input = await response.Content.ReadAsStreamAsync(token);
                    await using var output = new FileStream(archive, FileMode.CreateNew, FileAccess.Write, FileShare.None, 81920, true);
                    var buffer = new byte[81920]; long received = 0; var lastPercent = -1;
                    while (true)
                    {
                        var read = await input.ReadAsync(buffer, token); if (read == 0) break;
                        received += read;
                        if (received > package.Size) throw new InvalidDataException("Download size does not match Roblox");
                        await output.WriteAsync(buffer.AsMemory(0, read), token);
                        var percent = (int)((completed + received) * 95 / total);
                        if (percent != lastPercent) { progress?.Report(new(percent, "Downloading")); lastPercent = percent; }
                    }
                    if (received != package.Size) throw new InvalidDataException("Download was incomplete   Try again");
                }
                await using (var file = File.OpenRead(archive))
                    if (!Convert.ToHexString(await MD5.HashDataAsync(file, token)).Equals(package.Hash, StringComparison.OrdinalIgnoreCase))
                        throw new InvalidDataException("Download check failed   Try again");
                progress?.Report(new((int)((completed + package.Size) * 95 / total), "Unpacking"));
                if (package.Name.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
                    await Task.Run(() => Extract(archive, Path.Combine(staging, Folders[package.Name]), package.Expanded, token), token);
                else File.Copy(archive, Path.Combine(staging, package.Name), false);
                File.Delete(archive); completed += package.Size;
            }
            var player = Path.Combine(staging, "RobloxPlayerBeta.exe");
            if (!File.Exists(player)) throw new InvalidDataException("This download did not include the Roblox player");
            await File.WriteAllTextAsync(Path.Combine(staging, "AppSettings.xml"),
                "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Settings><ContentFolder>content</ContentFolder><BaseUrl>http://www.roblox.com</BaseUrl></Settings>", token);
            await File.WriteAllTextAsync(Path.Combine(staging, "download.complete"), version, token);
            token.ThrowIfCancellationRequested();
            Directory.Move(staging, target);
            progress?.Report(new(100, "Downloaded"));
            return Path.Combine(target, "RobloxPlayerBeta.exe");
        }
        finally
        {
            // Only this newly created partial folder can be removed. Existing installations are never replaced.
            if (Path.GetDirectoryName(Path.GetFullPath(staging)) == root && Directory.Exists(staging))
                try { Directory.Delete(staging, true); } catch (IOException) { } catch (UnauthorizedAccessException) { }
        }
    }

    internal static void Extract(string archive, string destination, long maximum, CancellationToken token)
    {
        Directory.CreateDirectory(destination);
        var prefix = Path.GetFullPath(destination).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        using var zip = ZipFile.OpenRead(archive);
        if (zip.Entries.Sum(e => e.Length) > maximum) throw new InvalidDataException("Unpacked size does not match Roblox");
        foreach (var entry in zip.Entries)
        {
            token.ThrowIfCancellationRequested();
            var relative = entry.FullName.Replace('\\', '/').TrimStart('/');
            if (entry.Length == 0 && relative is "" or "./") continue;
            if (relative.StartsWith('/') || relative.Contains(':') || relative.Split('/').Any(p => p is "." or ".." || p.EndsWith(' ') || p.EndsWith('.')) ||
                ((entry.ExternalAttributes >> 16) & 0xF000) == 0xA000)
                throw new InvalidDataException("Invalid path in Roblox package " + relative);
            var path = Path.GetFullPath(Path.Combine(destination, relative));
            if (!path.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Invalid path in Roblox package " + relative);
            if (relative.EndsWith('/')) { Directory.CreateDirectory(path); continue; }
            Directory.CreateDirectory(Path.GetDirectoryName(path)!);
            entry.ExtractToFile(path, overwrite: true);
        }
    }

    private static async Task<byte[]> ReadBoundedAsync(HttpResponseMessage response, int maximum, CancellationToken token)
    {
        await using var input = await response.Content.ReadAsStreamAsync(token);
        using var result = new MemoryStream(); var buffer = new byte[81920];
        while (true)
        {
            var count = await input.ReadAsync(buffer, token); if (count == 0) break;
            if (result.Length + count > maximum) throw new InvalidDataException("Roblox response is too large");
            result.Write(buffer, 0, count);
        }
        return result.ToArray();
    }
    public void Dispose() => http.Dispose();
}



