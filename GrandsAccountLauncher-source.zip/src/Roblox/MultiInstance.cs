using System.Diagnostics;

namespace GrandsAccountLauncher.Roblox;

// A dedicated thread owns and releases the mutex: mutex ownership is thread-affine.
public sealed class MultiInstance : IDisposable
{
    private readonly ManualResetEventSlim stop = new();
    private Thread? owner;
    private bool disposed;
    private readonly string mutexName;
    private readonly bool checkPlayers;
    public MultiInstance() : this("ROBLOX_singletonMutex", true) { }
    internal MultiInstance(string name, bool checkPlayers) { mutexName = name; this.checkPlayers = checkPlayers; }
    public bool Enabled { get; private set; }
    public string Status { get; private set; } = "Starting multi-instance…";

    public void EnsureEnabled()
    {
        if (Enabled) return;
        owner?.Join();
        var existing = Process.GetProcessesByName("RobloxPlayerBeta");
        try
        {
            if (checkPlayers && existing.Length > 0)
            {
                Status = "Close existing Roblox players, then retry Join to enable multi-instance.";
                throw new InvalidOperationException(Status);
            }
        }
        finally { foreach (var process in existing) process.Dispose(); }
        using var ready = new ManualResetEventSlim();
        Exception? failure = null;
        owner = new Thread(() =>
        {
            Mutex? mutex = null;
            var owns = false;
            try
            {
                mutex = new Mutex(true, mutexName, out owns);
                if (!owns) throw new InvalidOperationException("Another launcher owns Roblox's multi-instance handle. Close it and Roblox, then retry Join.");
                Enabled = true;
                Status = "Multi-instance ready";
                ready.Set();
                stop.Wait();
            }
            catch (Exception ex) { failure = ex; Status = ex.Message; ready.Set(); }
            finally
            {
                if (owns) mutex?.ReleaseMutex();
                mutex?.Dispose();
                Enabled = false;
            }
        }) { IsBackground = true, Name = "Roblox multi-instance owner" };
        owner.Start();
        ready.Wait();
        if (failure is not null) throw failure;
    }

    public void Dispose() { if (disposed) return; disposed = true; stop.Set(); owner?.Join(); stop.Dispose(); }
}
