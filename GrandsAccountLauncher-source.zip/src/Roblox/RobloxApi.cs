using System.Net;
using System.Text.Json;

namespace GrandsAccountLauncher.Roblox;

public sealed record RobloxUser(long Id, string Name, string DisplayName = "");
public sealed class SessionExpiredException() : Exception("Session expired. Sign in again.");
public sealed class RobloxRateLimitException(string? retryAfter) : InvalidOperationException("Roblox is rate-limiting requests. Wait for the retry time before trying again.")
{ public string? RetryAfter { get; } = retryAfter; }

public sealed class RobloxApi : IDisposable
{
    private readonly HttpClient http;
    public RobloxApi(HttpMessageHandler? handler = null)
    {
        http = new HttpClient(handler ?? new HttpClientHandler { UseCookies = false, AllowAutoRedirect = false,
            AutomaticDecompression = DecompressionMethods.All }) { Timeout = TimeSpan.FromSeconds(25) };
    }

    private static HttpRequestMessage Request(HttpMethod method, string url, string cookie, string? csrf = null)
    {
        if (string.IsNullOrEmpty(cookie)) throw new SessionExpiredException();
        if (cookie.Any(c => char.IsControl(c) || c == ';')) throw new InvalidDataException("Invalid session data. Sign in again.");
        var request = new HttpRequestMessage(method, url);
        request.Headers.Add("Cookie", ".ROBLOSECURITY=" + cookie);
        request.Headers.Add("Referer", "https://www.roblox.com/");
        request.Headers.Add("Origin", "https://www.roblox.com");
        request.Headers.Add("RBXAuthenticationNegotiation", "1");
        if (csrf is not null) request.Headers.Add("x-csrf-token", csrf);
        if (method == HttpMethod.Post) request.Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json");
        return request;
    }

    public async Task<RobloxUser> GetUserAsync(string cookie, CancellationToken cancellation = default)
    {
        using var request = Request(HttpMethod.Get, "https://users.roblox.com/v1/users/authenticated", cookie);
        request.Headers.CacheControl = new() { NoCache = true, NoStore = true };
        using var response = await http.SendAsync(request, cancellation);
        CheckStatus(response);
        using var document = JsonDocument.Parse(await response.Content.ReadAsStringAsync(cancellation));
        return new(document.RootElement.GetProperty("id").GetInt64(), document.RootElement.GetProperty("name").GetString()!,
            document.RootElement.TryGetProperty("displayName", out var display) ? display.GetString() ?? "" : "");
    }

    public async Task SetDisplayNameAsync(Account account, string name, CancellationToken cancellation = default)
    {
        cancellation.ThrowIfCancellationRequested();
        if (string.IsNullOrWhiteSpace(name) || name.Any(char.IsControl))
            throw new ArgumentException("Enter a display name");
        var user = await GetUserAsync(account.Cookie, cancellation);
        if ((account.UserId > 0 && user.Id != account.UserId) ||
            (account.UserId == 0 && !user.Name.Equals(account.Username, StringComparison.OrdinalIgnoreCase)))
            throw new SessionExpiredException();
        if (user.DisplayName == name) { account.UserId = user.Id; account.DisplayName = user.DisplayName; return; }
        string? csrf = null;
        for (var attempt = 0; attempt < 3; attempt++)
        {
            cancellation.ThrowIfCancellationRequested();
            using var request = Request(HttpMethod.Patch, $"https://users.roblox.com/v1/users/{user.Id}/display-names", account.Cookie, csrf);
            request.Content = new StringContent(JsonSerializer.Serialize(new { newDisplayName = name }), System.Text.Encoding.UTF8, "application/json");
            using var response = await http.SendAsync(request, cancellation);
            if (response.StatusCode == HttpStatusCode.Forbidden &&
                response.Headers.TryGetValues("x-csrf-token", out var tokens) && attempt < 2)
            { csrf = tokens.First(); continue; }
            if (response.StatusCode == HttpStatusCode.BadRequest)
                throw new InvalidOperationException(await DisplayNameErrorAsync(response, cancellation));
            CheckStatus(response);
            await ConfirmDisplayNameAsync(account, user.Id, name, cancellation);
            return;
        }
    }

    private async Task ConfirmDisplayNameAsync(Account account, long userId, string name, CancellationToken cancellation)
    {
        const string unconfirmed = "Could not confirm the change in Roblox settings   Check Roblox before trying again";
        for (var attempt = 0; attempt < 3; attempt++)
        {
            if (attempt > 0) await Task.Delay(1000, cancellation);
            RobloxUser saved;
            try { saved = await GetUserAsync(account.Cookie, cancellation); }
            catch (RobloxRateLimitException) { throw; }
            catch (OperationCanceledException) when (cancellation.IsCancellationRequested) { throw; }
            catch (Exception ex) { throw new InvalidOperationException(unconfirmed, ex); }
            if (saved.Id != userId) throw new InvalidOperationException(unconfirmed);
            if (saved.DisplayName != name) continue;
            account.UserId = saved.Id;
            account.DisplayName = saved.DisplayName;
            return;
        }
        throw new InvalidOperationException(unconfirmed);
    }

    private static async Task<string> DisplayNameErrorAsync(HttpResponseMessage response, CancellationToken cancellation)
    {
        try
        {
            using var body = JsonDocument.Parse(await response.Content.ReadAsStringAsync(cancellation));
            var code = body.RootElement.GetProperty("errors")[0].GetProperty("code").GetInt32();
            return code switch
            {
                1 => "Display name is too short",
                2 => "Display name is too long",
                3 => "Roblox does not allow these characters",
                4 => "Roblox blocked this display name   Choose another name",
                8 => "Roblox does not allow this mix of characters",
                _ => "Roblox rejected this display name"
            };
        }
        catch (Exception ex) when (ex is JsonException or KeyNotFoundException or InvalidOperationException or IndexOutOfRangeException)
        { return "Roblox rejected this display name"; }
    }

    public async Task<string> GetTicketAsync(string cookie, CancellationToken cancellation = default)
    {
        string? csrf = null;
        for (var attempt = 0; attempt < 3; attempt++)
        {
            using var request = Request(HttpMethod.Post, "https://auth.roblox.com/v1/authentication-ticket", cookie, csrf);
            using var response = await http.SendAsync(request, cancellation);
            if (response.StatusCode == HttpStatusCode.Forbidden &&
                response.Headers.TryGetValues("x-csrf-token", out var tokens) && attempt < 2)
            { csrf = tokens.First(); continue; }
            CheckStatus(response);
            if (response.Headers.TryGetValues("rbx-authentication-ticket", out var tickets) &&
                tickets.FirstOrDefault() is { Length: > 0 } ticket) return ticket;
            throw new InvalidOperationException("Roblox did not return a launch ticket. Try signing in again.");
        }
        throw new InvalidOperationException("Roblox rejected the launch request. Try signing in again.");
    }

    private static void CheckStatus(HttpResponseMessage response)
    {
        if (response.StatusCode == HttpStatusCode.Unauthorized) throw new SessionExpiredException();
        if (response.StatusCode == HttpStatusCode.TooManyRequests)
            throw new RobloxRateLimitException(response.Headers.TryGetValues("Retry-After", out var values) ? values.FirstOrDefault() : null);
        if (response.StatusCode == HttpStatusCode.Forbidden)
            throw new InvalidOperationException("Roblox blocked this request. Open Sign in to complete any verification, then retry.");
        if (!response.IsSuccessStatusCode)
            throw new InvalidOperationException($"Roblox returned HTTP {(int)response.StatusCode}. Try again later.");
    }
    public void Dispose() => http.Dispose();
}

