using System.Diagnostics;
using Microsoft.Win32;

namespace GrandsAccountLauncher.Roblox;

public sealed class ClientLauncher : IDisposable
{
    private sealed record Session(Process Process, DateTime StartedUtc);
    private readonly Dictionary<string, Session> sessions = [];
    public int RunningCount => sessions.Keys.Count(id => ProcessId(id) is not null);

    public int? ProcessId(string accountId)
    {
        if (!sessions.TryGetValue(accountId, out var session)) return null;
        try
        {
            return !session.Process.HasExited && session.Process.StartTime.ToUniversalTime() == session.StartedUtc
                ? session.Process.Id : null;
        }
        catch (InvalidOperationException) { return null; }
        catch (System.ComponentModel.Win32Exception) { return null; }
    }

    public static string FindClient(string? selectedPath = null)
    {
        if (!string.IsNullOrWhiteSpace(selectedPath))
        {
            if (!Path.IsPathFullyQualified(selectedPath) || !IsClient(selectedPath))
                throw new InvalidOperationException("The selected Roblox version is missing   Choose a version again");
            return Path.GetFullPath(selectedPath);
        }
        return InstalledClients().FirstOrDefault() ?? throw new InvalidOperationException("Install Roblox then choose a version");
    }

    public static List<string> InstalledClients(IEnumerable<string>? versionRoots = null)
    {
        var clients = new List<string>();
        // The registered installation is the automatic choice when available.
        if (versionRoots is null)
        {
        using var key = Registry.ClassesRoot.OpenSubKey(@"roblox-player\shell\open\command");
        if (key?.GetValue(null) is string command && command.StartsWith('"'))
        {
            var end = command.IndexOf('"', 1);
            if (end > 1 && IsClient(command[1..end])) clients.Add(command[1..end]);
        }
        }
        versionRoots ??= new[] { Environment.SpecialFolder.LocalApplicationData, Environment.SpecialFolder.ProgramFilesX86,
            Environment.SpecialFolder.ProgramFiles }.Select(root => Path.Combine(Environment.GetFolderPath(root), "Roblox", "Versions"));
        var found = new List<string>();
        foreach (var versions in versionRoots)
        {
            if (!Directory.Exists(versions)) continue;
            try { found.AddRange(Directory.EnumerateDirectories(versions).Select(d => Path.Combine(d, "RobloxPlayerBeta.exe")).Where(IsClient)); }
            catch (UnauthorizedAccessException) { }
            catch (IOException) { }
        }
        clients.AddRange(found.OrderByDescending(File.GetLastWriteTimeUtc));
        return clients.Select(Path.GetFullPath).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
    }
    private static bool IsClient(string path) => File.Exists(path) &&
        Path.GetFileName(path).Equals("RobloxPlayerBeta.exe", StringComparison.OrdinalIgnoreCase);

    public static string BuildProtocol(string ticket, GameTarget game)
    {
        if (game.PlaceId <= 0 || (game.JobId is not null && !Guid.TryParseExact(game.JobId, "D", out _)))
            throw new ArgumentException("Invalid game target.");
        var tracker = System.Security.Cryptography.RandomNumberGenerator.GetInt32(1_000_000, int.MaxValue);
        var target = "https://assetgame.roblox.com/game/PlaceLauncher.ashx?request=" +
            (game.JobId is null ? "RequestGame" : "RequestGameJob") + $"&browserTrackerId={tracker}&placeId={game.PlaceId}" +
            (game.JobId is null ? "" : "&gameId=" + Uri.EscapeDataString(game.JobId)) + "&isPlayTogetherGame=false";
        return "roblox-player:1+launchmode:play+gameinfo:" + Uri.EscapeDataString(ticket) +
            "+launchtime:" + DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() +
            "+placelauncherurl:" + Uri.EscapeDataString(target) + "+browsertrackerid:" + tracker + "+robloxLocale:en_us+gameLocale:en_us+channel:";
    }

    public async Task LaunchAsync(Account account, GameTarget game, string client, string ticket, CancellationToken cancellation)
    {
        if (ProcessId(account.Id) is not null) throw new InvalidOperationException("This account already has a tracked player. Use Rejoin game or Stop selected.");
        cancellation.ThrowIfCancellationRequested();
        var info = new ProcessStartInfo(client) { UseShellExecute = false, WorkingDirectory = Path.GetDirectoryName(client)! };
        info.ArgumentList.Add(BuildProtocol(ticket, game));
        var process = Process.Start(info) ?? throw new InvalidOperationException("The Roblox player could not be started.");
        var session = new Session(process, process.StartTime.ToUniversalTime());
        if (sessions.Remove(account.Id, out var old)) old.Process.Dispose();
        sessions.Add(account.Id, session);
        // Keep this exact process associated even on cancellation/timeout so Stop and retry remain safe.
        for (var i = 0; i < 100; i++)
        {
            await Task.Delay(300, cancellation);
            process.Refresh();
            if (process.HasExited)
                throw new InvalidOperationException("Roblox exited during startup. Check for a client update or another instance manager, then retry.");
            if (process.MainWindowHandle != IntPtr.Zero)
            {
                account.LastGame = game;
                account.LastLaunchUtc = DateTime.UtcNow;
                return;
            }
        }
        throw new InvalidOperationException("The player started but no window appeared within 30 seconds. Check Roblox, or use Stop selected before retrying.");
    }

    public async Task StopAsync(string accountId, CancellationToken cancellation = default)
    {
        cancellation.ThrowIfCancellationRequested();
        if (ProcessId(accountId) is null) return;
        var session = sessions[accountId];
        // Kill only the exact Process object started here, never all Roblox processes or an arbitrary PID.
        try
        {
            session.Process.Kill(entireProcessTree: false);
            await session.Process.WaitForExitAsync(cancellation).WaitAsync(TimeSpan.FromSeconds(10), cancellation);
        }
        catch (InvalidOperationException) when (ProcessId(accountId) is null) { }
        if (sessions.Remove(accountId)) session.Process.Dispose();
    }

    public void Dispose()
    {
        foreach (var session in sessions.Values) session.Process.Dispose();
        sessions.Clear();
    }
}
