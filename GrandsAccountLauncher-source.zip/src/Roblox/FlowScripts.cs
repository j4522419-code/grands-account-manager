using System.Text.Json;

namespace GrandsAccountLauncher.Roblox;

internal sealed record FlowState(bool Challenge, bool LoginRejected, bool RateLimited, string Progress, bool UserActive);

internal static class FlowScripts
{
    // Return categories only: page text can contain passwords, session tokens, or verification codes.
    public const string Observe = """
        (()=>{
          if(!window.__grandsInteractionBound){window.__grandsInteractionBound=true;for(const kind of ['pointerdown','keydown','input'])document.addEventListener(kind,e=>{if(e.isTrusted)window.__grandsInteractionAt=Date.now();},true);}
          const visible=e=>e&&e.getClientRects().length>0&&!e.closest('[hidden],[aria-hidden="true"]')&&getComputedStyle(e).visibility!=='hidden';
          const alerts=[...document.querySelectorAll('[role="alert"],.text-error,.input-validation,[id$="-validation"],.form-control-label')].filter(visible).map(e=>e.textContent.trim()).join(' ');
          const dialogs=[...document.querySelectorAll('[role="dialog"],.modal')].filter(visible).map(e=>e.textContent).join(' ');
          const challenge=[...document.querySelectorAll('iframe')].some(e=>visible(e)&&/captcha|arkoselabs|funcaptcha|challenge/i.test((e.src||'')+' '+(e.title||'')))||/verify you are human|complete.*challenge|security check|two.step verification|verification code|solve.*puzzle/i.test(dialogs);
          return {Challenge:challenge,LoginRejected:/incorrect.*(username|password)|invalid.*(username|password)|username or password.*incorrect/i.test(alerts),
            RateLimited:/too many|rate.limit|try again later/i.test(alerts),
            UserActive:Date.now()-(window.__grandsInteractionAt||0)<10000,
            Progress:[location.pathname,document.readyState,window.__grandsLoginState?.submitted,
              [...document.querySelectorAll('input,select,[role="combobox"],button')].filter(visible).length].join('|')};
        })()
        """;

    public static string Login(string username, string password) => $$"""
        (()=>{
          if(location.origin!=='https://www.roblox.com'||!/^\/login\/?$/i.test(location.pathname))return 'wrong-page';
          const visible=e=>e&&e.getClientRects().length>0&&!e.closest('[hidden],[aria-hidden="true"]')&&getComputedStyle(e).visibility!=='hidden';
          const state=window.__grandsLoginState||={inputs:new WeakSet(),clicked:new WeakMap(),submitted:false,readyAt:0};
          const inputs=[...document.querySelectorAll('input')].filter(e=>visible(e)&&!e.disabled);
          const p=inputs.find(e=>e.type==='password'||e.autocomplete==='current-password');
          const scope=p?.form||document;
          const u=inputs.find(e=>e.id==='login-username'||e.autocomplete==='username')||inputs.find(e=>(!p?.form||p.form.contains(e))&&/user|email|phone/i.test([e.name,e.id,e.placeholder,e.getAttribute('aria-label')].join(' '))&&e.type!=='password');
          const buttons=[...scope.querySelectorAll('button,input[type="submit"]')].filter(visible);
          const b=buttons.find(e=>e.id==='login-button')||buttons.find(e=>/^(log\s*in|sign\s*in|continue|next)$/i.test((e.getAttribute('aria-label')||e.textContent||e.value).trim()));
          if(!u&&!p)return 'waiting';
          const set=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;
          for(const [el,value] of [[u,{{JsonSerializer.Serialize(username)}}],[p,{{JsonSerializer.Serialize(password)}}]]){
            if(!el||state.inputs.has(el))continue;
            set.call(el,value);el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));
            state.inputs.add(el);state.readyAt=Date.now()+400;
          }
          if(state.submitted)return 'submitted';
          const stage=p?'password':'username';
          if(b&&!b.disabled&&b.getAttribute('aria-disabled')!=='true'&&state.clicked.get(b)!==stage&&Date.now()>=state.readyAt){
            state.clicked.set(b,stage);if(p)state.submitted=true;b.click();return p?'submitted':'advanced';
          }
          return 'preparing';
        })()
        """;
}

