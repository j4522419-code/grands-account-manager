using GrandsAccountLauncher.Storage;

namespace GrandsAccountLauncher.Ui;

internal sealed class PinForm : Form
{
    public string Pin { get; private set; } = "";
    public PinForm(bool exporting, int count = 0)
    {
        Theme.Window(this); Text = exporting ? "Export accounts" : "Import accounts";
        ClientSize = new(400, 210); FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = false;
        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new(24), ColumnCount = 1, RowCount = 4 };
        layout.Controls.Add(Theme.Label(exporting ? $"Choose a four digit PIN for {count} accounts" : "Enter the four digit PIN"));
        var input = Theme.Input(); input.MaxLength = 4; input.UseSystemPasswordChar = true;
        input.KeyPress += (_, e) => { if (!char.IsControl(e.KeyChar) && !char.IsAsciiDigit(e.KeyChar)) e.Handled = true; };
        layout.Controls.Add(input);
        var feedback = Theme.Label("", true); layout.Controls.Add(feedback);
        var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true };
        var submit = Theme.Button(exporting ? "Export" : "Import", (_, _) =>
        {
            if (!AccountTransfer.IsPin(input.Text)) { feedback.Text = "Enter four digits"; return; }
            Pin = input.Text; DialogResult = DialogResult.OK;
        }, true);
        var cancel = Theme.Button("Cancel", (_, _) => Close()); cancel.DialogResult = DialogResult.Cancel;
        buttons.Controls.AddRange([submit, cancel]); layout.Controls.Add(buttons); Controls.Add(layout);
        AcceptButton = submit; CancelButton = cancel;
        FormClosed += (_, _) => input.Clear();
    }
}
