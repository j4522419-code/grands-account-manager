using GrandsAccountLauncher.Roblox;
using GrandsAccountLauncher.Storage;

namespace GrandsAccountLauncher.Ui;

internal sealed class MainForm : Form
{
    private readonly AccountStore store;
    private readonly RobloxApi api = new();
    private readonly ClientLauncher launcher = new();
    private readonly MultiInstance multi = new();
    private readonly DataGridView grid = new();
    private readonly ContextMenuStrip accountMenu = new();
    private readonly TextBox game = Theme.Input("Game link or place ID");
    private readonly TextBox job = Theme.Input("Optional server ID");
    private readonly TextBox search = Theme.Input("Search accounts");
    private readonly Label summary = Theme.Label("", true);
    private readonly Label multiStatus = Theme.Label("", true);
    private readonly Label status = Theme.Label("Ready", true);
    private readonly List<Button> actions = [];
    private readonly System.Windows.Forms.Timer refresh = new() { Interval = 1500 };
    private Button cancel = null!;
    private CancellationTokenSource? operation;
    private string? queueClient;
    private bool pendingClose;
    private bool disposed;
    private readonly bool preview;

    public MainForm(AccountStore store, bool preview = false)
    {
        this.store = store; this.preview = preview;
        Theme.Window(this); Text = "Grands Account Launcher"; ClientSize = new(1020, 680); MinimumSize = new(980, 640);
        var root = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new(26, 22, 26, 18), ColumnCount = 1, RowCount = 7 };
        root.RowStyles.Add(new(SizeType.Absolute, 60)); root.RowStyles.Add(new(SizeType.Absolute, 52));
        root.RowStyles.Add(new(SizeType.Absolute, 46)); root.RowStyles.Add(new(SizeType.Percent, 100));
        root.RowStyles.Add(new(SizeType.Absolute, 92)); root.RowStyles.Add(new(SizeType.Absolute, 54));
        root.RowStyles.Add(new(SizeType.Absolute, 42));

        var heading = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1 };
        heading.RowStyles.Add(new(SizeType.Percent, 100));
        heading.ColumnStyles.Add(new(SizeType.Percent, 65)); heading.ColumnStyles.Add(new(SizeType.Percent, 35));
        var brand = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false };
        var title = Theme.Label("Grands Account Launcher"); title.Font = new("Segoe UI Semibold", 23); brand.Controls.Add(title);

        summary.AutoSize = false; summary.Dock = DockStyle.Fill; summary.TextAlign = ContentAlignment.MiddleRight; heading.Controls.Add(brand); heading.Controls.Add(summary); root.Controls.Add(heading);

        var toolbar = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false };
        AddButton(toolbar, "Add account", (_, _) => AddAccount(), true);
        AddButton(toolbar, "Bulk add", (_, _) => BulkAdd());
        AddButton(toolbar, "Display names", async (_, _) => await ChangeDisplayNamesAsync());
        AddButton(toolbar, "Sign in", async (_, _) => await RunQueue("Sign in", SignInAsync));
        AddButton(toolbar, "Edit password", (_, _) => EditAccount());
        AddButton(toolbar, "Remove", (_, _) => RemoveAccounts());
        root.Controls.Add(toolbar);
        var filter = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2 };
        filter.ColumnStyles.Add(new(SizeType.Absolute, 290)); filter.ColumnStyles.Add(new(SizeType.Percent, 100));
        search.Margin = new(0, 0, 20, 6); filter.Controls.Add(search);
        var versionBar = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft };
        AddButton(versionBar, "Roblox version", (_, _) => ChooseVersion());
        AddButton(versionBar, "Export", async (_, _) => await ExportAccountsAsync());
        AddButton(versionBar, "Import", async (_, _) => await ImportAccountsAsync());
        filter.Controls.Add(versionBar); root.Controls.Add(filter);
        SetupGrid(); root.Controls.Add(grid);

        var target = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 3, Padding = new(0, 20, 0, 0) };
        target.ColumnStyles.Add(new(SizeType.Percent, 60)); target.ColumnStyles.Add(new(SizeType.Percent, 40));
        target.RowStyles.Add(new(SizeType.Absolute, 26)); target.RowStyles.Add(new(SizeType.Absolute, 44)); target.RowStyles.Add(new(SizeType.Percent, 100));
        target.Controls.Add(Theme.Label("Game"), 0, 0); target.Controls.Add(Theme.Label("Server"), 1, 0);
        game.Text = store.Data.LastGameInput; game.Margin = new(0, 0, 18, 0); job.Margin = new(0);
        target.Controls.Add(game, 0, 1); target.Controls.Add(job, 1, 1);
        root.Controls.Add(target);

        var launchBar = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false };
        AddButton(launchBar, "Join game", async (_, _) =>
        {
            GameTarget target;
            try { target = GameInput.Parse(game.Text, job.Text); }
            catch (Exception ex) { Error(ex.Message); return; }
            store.Data.LastGameInput = game.Text.Trim();
            await RunQueue("Join", (account, token) => LaunchAsync(account, target, false, token), launch: true);
        }, true);
        AddButton(launchBar, "Rejoin game", async (_, _) => await RunQueue("Rejoin", (account, token) =>
            LaunchAsync(account, account.LastGame ?? throw new InvalidOperationException("Join a game first so this account has a saved game target."), true, token), launch: true));
        AddButton(launchBar, "Stop selected", async (_, _) => await RunQueue("Stop", async (account, token) =>
        {
            await launcher.StopAsync(account.Id, token); account.Status = "Stopped";
        }));
        AddButton(launchBar, "Close all Roblox", async (_, _) => await CloseAllRobloxAsync());
        cancel = Theme.Button("Cancel", (_, _) => operation?.Cancel()); cancel.Enabled = false;
        launchBar.Controls.Add(cancel); root.Controls.Add(launchBar);

        var footer = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2 };
        footer.ColumnStyles.Add(new(SizeType.Percent, 68)); footer.ColumnStyles.Add(new(SizeType.Percent, 32));
        status.AutoSize = false; status.Dock = DockStyle.Fill; status.AutoEllipsis = true;
        multiStatus.AutoSize = false; multiStatus.Dock = DockStyle.Fill; multiStatus.TextAlign = ContentAlignment.TopRight;
        footer.Controls.Add(status); footer.Controls.Add(multiStatus); root.Controls.Add(footer); Controls.Add(root);
        search.TextChanged += (_, _) => RefreshRows();
        grid.SelectionChanged += (_, _) => UpdateSummary();
        refresh.Tick += (_, _) => { RefreshStatus();  };
        Shown += (_, _) =>
        {
            if (!preview) { try { multi.EnsureEnabled(); } catch (Exception ex) { status.Text = Theme.Plain(ex.Message); } }
            RefreshRows(); RefreshStatus(); refresh.Start();
        };
        FormClosing += (_, e) =>
        {
            if (operation is not null) { pendingClose = true; operation.Cancel(); e.Cancel = true; return; }
            refresh.Stop();
        };
    }

    private void AddButton(FlowLayoutPanel parent, string text, EventHandler action, bool primary = false)
    { var button = Theme.Button(text, action, primary); parent.Controls.Add(button); actions.Add(button); }

    private void SetupGrid()
    {
        grid.Dock = DockStyle.Fill; grid.BackgroundColor = Theme.Surface; grid.BorderStyle = BorderStyle.None;
        grid.ReadOnly = true; grid.AllowUserToAddRows = false; grid.AllowUserToDeleteRows = false;
        grid.AllowUserToResizeRows = false; grid.RowHeadersVisible = false;
        grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect; grid.MultiSelect = true;
        accountMenu.BackColor = Theme.Surface; accountMenu.ForeColor = Theme.Text; accountMenu.ShowImageMargin = false;
        foreach (var (label, field) in new[] { ("Copy username", CopyField.Username), ("Copy password", CopyField.Password),
            ("Copy cookie", CopyField.Cookie), ("Copy combo", CopyField.Combo) })
            accountMenu.Items.Add(label, null, (_, _) => CopyAccounts(field));
        accountMenu.Opening += (_, e) => e.Cancel = operation is not null || Selected().Count == 0;
        grid.ContextMenuStrip = accountMenu;
        grid.CellMouseDown += (_, e) =>
        {
            if (e.Button != MouseButtons.Right || e.RowIndex < 0 || operation is not null) return;
            if (!grid.Rows[e.RowIndex].Selected)
            { grid.ClearSelection(); grid.Rows[e.RowIndex].Selected = true; }
        };
        grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        grid.EnableHeadersVisualStyles = false; grid.ColumnHeadersHeight = 42; grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
        grid.ColumnHeadersDefaultCellStyle = new() { BackColor = Theme.Background, ForeColor = Theme.Muted,
            Font = new("Segoe UI Semibold", 9), Padding = new(12, 0, 0, 0), SelectionBackColor = Theme.Background };
        grid.DefaultCellStyle = new() { BackColor = Theme.Surface, ForeColor = Theme.Text,
            SelectionBackColor = Theme.Selection, SelectionForeColor = Theme.SelectionText, Padding = new(12, 0, 0, 0) };
        grid.AlternatingRowsDefaultCellStyle.BackColor = Theme.AlternateRow;
        grid.GridColor = Theme.Border; grid.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
        grid.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None; grid.RowTemplate.Height = 48;
        foreach (var (name, title, weight) in new[] { ("account", "Account", 30), ("status", "Status", 40),
            ("display", "Display name", 30) })
        {
            grid.Columns.Add(new DataGridViewTextBoxColumn { Name = name, HeaderText = title, FillWeight = weight,
                SortMode = DataGridViewColumnSortMode.NotSortable });
        }
    }

    private List<Account> Selected() => grid.SelectedRows.Cast<DataGridViewRow>().OrderBy(r => r.Index).Select(r => (Account)r.Tag!).ToList();
    private void RefreshRows()
    {
        var selected = Selected().Select(a => a.Id).ToHashSet();
        grid.Rows.Clear();
        foreach (var account in store.Data.Accounts.Where(a => a.Username.Contains(search.Text.Trim(), StringComparison.OrdinalIgnoreCase)))
        {
            var index = grid.Rows.Add(account.Username, Theme.Plain(account.Status), account.DisplayName);
            grid.Rows[index].Tag = account;
        }
        grid.ClearSelection();
        foreach (DataGridViewRow row in grid.Rows) row.Selected = selected.Contains(((Account)row.Tag!).Id);
        RefreshStatus();
    }
    private void RefreshStatus()
    {
        foreach (DataGridViewRow row in grid.Rows)
        {
            var account = (Account)row.Tag!;
            var pid = launcher.ProcessId(account.Id);
            if (pid is null && account.Status == "Player opened") account.Status = "Player closed";
            row.Cells[1].Value = Theme.Plain(account.Status); row.Cells[1].ToolTipText = Theme.Plain(account.Status);
            row.Cells[2].Value = account.DisplayName;
        }
        multiStatus.Text = multi.Enabled || preview ? "Multi instance ready" : "Close Roblox then reopen this app";
        UpdateSummary();
    }
    private void UpdateSummary() => summary.Text = $"{store.Data.Accounts.Count} accounts   {grid.SelectedRows.Count} selected";

    private void CopyAccounts(CopyField field)
    {
        var selected = Selected();
        if (selected.Count == 0) return;
        try
        {
            Clipboard.SetDataObject(AccountCopy.Format(selected, field), true, 5, 100);
            status.Text = $"Copied {selected.Count} accounts";
        }
        catch (Exception) { Error("Could not copy   Try again"); }
    }

    private async Task ExportAccountsAsync()
    {
        var selected = Selected();
        if (selected.Count == 0) selected = store.Data.Accounts.ToList();
        if (selected.Count == 0) { Error("Add accounts first"); return; }
        using var pin = new PinForm(true, selected.Count);
        if (pin.ShowDialog(this) != DialogResult.OK) return;
        using var file = new SaveFileDialog { Title = "Export accounts", Filter = "Encrypted accounts|*.txt",
            DefaultExt = "txt", AddExtension = true, FileName = "GrandsAccounts.txt", OverwritePrompt = true };
        if (file.ShowDialog(this) != DialogResult.OK) return;
        await TransferAsync(async token =>
        {
            var encrypted = await Task.Run(() => AccountTransfer.Encrypt(selected, pin.Pin), token);
            token.ThrowIfCancellationRequested();
            await Task.Run(() => AccountTransfer.Write(file.FileName, encrypted), token);
            status.Text = $"Exported {selected.Count} accounts";
        });
    }

    private async Task ImportAccountsAsync()
    {
        using var file = new OpenFileDialog { Title = "Import accounts", Filter = "Encrypted accounts|*.txt", CheckFileExists = true };
        if (file.ShowDialog(this) != DialogResult.OK) return;
        using var pin = new PinForm(false);
        if (pin.ShowDialog(this) != DialogResult.OK) return;
        await TransferAsync(async token =>
        {
            var imported = await Task.Run(() => AccountTransfer.Decrypt(AccountTransfer.Read(file.FileName), pin.Pin), token);
            token.ThrowIfCancellationRequested();
            var added = store.ImportAccounts(imported);
            RefreshRows();
            foreach (DataGridViewRow row in grid.Rows) row.Selected = added.Contains((Account)row.Tag!);
            status.Text = $"Imported {added.Count} accounts   {imported.Count - added.Count} duplicates skipped";
        });
    }

    private async Task TransferAsync(Func<CancellationToken, Task> action)
    {
        if (operation is not null) return;
        operation = new();
        foreach (var button in actions) button.Enabled = false;
        grid.Enabled = search.Enabled = false; cancel.Enabled = true; status.Text = "Working";
        try { await action(operation.Token); }
        catch (OperationCanceledException) { status.Text = "Cancelled"; }
        catch (Exception ex) { status.Text = "Could not finish"; if (!pendingClose) Error(ex.Message); }
        finally
        {
            operation.Dispose(); operation = null;
            foreach (var button in actions) button.Enabled = true;
            grid.Enabled = search.Enabled = true; cancel.Enabled = false;
            if (pendingClose) Close();
        }
    }

    private void ChooseVersion()
    {
        using var dialog = new ClientVersionForm(store.Data.RobloxClientPath);
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        var previous = store.Data.RobloxClientPath;
        store.Data.RobloxClientPath = dialog.SelectedPath;
        try { store.Save(); status.Text = "Roblox version saved for all accounts"; }
        catch (Exception ex) { store.Data.RobloxClientPath = previous; Error(ex.Message); }
    }

    private void AddAccount()
    {
        using var dialog = new AccountForm();
        if (dialog.ShowDialog(this) != DialogResult.OK || dialog.Result is null) return;
        AddCredentials([dialog.Result]);
    }
    private async Task ChangeDisplayNamesAsync()
    {
        var count = Selected().Count;
        if (count == 0) { Error("Select accounts first"); return; }
        using var dialog = new DisplayNamesForm(count);
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        await RunQueue("Change names", async (account, token) =>
        {
            if (account.Cookie.Length == 0) await SignInAsync(account, token);
            try { await api.SetDisplayNameAsync(account, dialog.DisplayName, token); }
            catch (SessionExpiredException)
            { account.Cookie = ""; await SignInAsync(account, token); await api.SetDisplayNameAsync(account, dialog.DisplayName, token); }
            account.Status = "Name saved in Roblox";
            try { store.Save(); }
            catch (Exception ex) { throw new IOException("Name changed on Roblox but could not save it here", ex); }
        });
    }
    private async Task CloseAllRobloxAsync()
    {
        if (operation is not null) return;
        operation = new CancellationTokenSource();
        foreach (var button in actions) button.Enabled = false;
        try
        {
            status.Text = "Closing Roblox";
            await RobloxProcesses.CloseAllAsync();
            RefreshStatus(); status.Text = "Roblox closed";
        }
        catch (Exception ex) { Error(ex.Message); }
        finally
        {
            operation.Dispose(); operation = null;
            if (!disposed) foreach (var button in actions) button.Enabled = true;
            if (pendingClose) Close();
        }
    }
    private void BulkAdd()
    {
        using var dialog = new BulkImportForm(store.Data.Accounts.Select(a => a.Username));
        if (dialog.ShowDialog(this) == DialogResult.OK) AddCredentials(dialog.Result);
    }
    private void AddCredentials(IEnumerable<Credentials> credentials)
    {
        var existing = store.Data.Accounts.Select(a => a.Username).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var added = credentials.Where(c => existing.Add(c.Username)).Select(c => new Account
            { Username = c.Username, Password = c.Password, Status = "Needs sign-in" }).ToList();
        if (added.Count == 0) { Error("That account is already saved. Use Edit password to update it."); return; }
        store.Data.Accounts.AddRange(added);
        try { store.Save(); }
        catch (Exception ex) { foreach (var a in added) store.Data.Accounts.Remove(a); Error("Could not save accounts: " + ex.Message); return; }
        RefreshRows();
        foreach (DataGridViewRow row in grid.Rows) row.Selected = added.Contains((Account)row.Tag!);
        status.Text = $"Added {added.Count} accounts";
    }
    private void EditAccount()
    {
        var selected = Selected();
        if (selected.Count != 1) { Error("Select one account to update its password."); return; }
        var account = selected[0];
        using var dialog = new AccountForm(account);
        if (dialog.ShowDialog(this) != DialogResult.OK || dialog.Result is null) return;
        var (oldPassword, oldCookie) = (account.Password, account.Cookie);
        account.Password = dialog.Result.Password; account.Cookie = "";
        try { store.Save(); account.Status = "Needs sign-in"; }
        catch (Exception ex) { account.Password = oldPassword; account.Cookie = oldCookie; Error("Could not save password: " + ex.Message); }
        RefreshStatus();
    }
    private void RemoveAccounts()
    {
        var selected = Selected();
        if (selected.Count == 0) { Error("Select accounts to remove."); return; }
        if (selected.Any(a => launcher.ProcessId(a.Id) is not null))
        { Error("Stop the selected running players before removing their accounts."); return; }
        if (MessageBox.Show(this, $"Remove {selected.Count} selected accounts", "Remove accounts",
            MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        var previous = store.Data.Accounts.ToList();
        foreach (var account in selected) store.Data.Accounts.Remove(account);
        try { store.Save(); RefreshRows(); }
        catch (Exception ex) { store.Data.Accounts = previous; Error("Could not remove accounts: " + ex.Message); }
    }

    private Task SignInAsync(Account account, CancellationToken token)
    {
        token.ThrowIfCancellationRequested(); account.Status = "Sign-in / verification"; RefreshStatus();
        using var login = new LoginForm(account, api);
        using var registration = token.Register(() =>
        {
            if (login.IsHandleCreated && !login.IsDisposed) login.BeginInvoke(() => login.Close());
        });
        if (login.ShowDialog(this) != DialogResult.OK || login.SessionCookie is null || login.User is null)
            throw new OperationCanceledException("Sign-in cancelled.", token);
        account.Cookie = login.SessionCookie; account.UserId = login.User.Id; account.Username = login.User.Name; account.DisplayName = login.User.DisplayName;
        account.Status = "Signed in";
        store.Save();
        return Task.CompletedTask;
    }

    private async Task LaunchAsync(Account account, GameTarget target, bool rejoin, CancellationToken token)
    {
        multi.EnsureEnabled();
        var client = queueClient ?? throw new InvalidOperationException("Choose a Roblox version first");
        if (!rejoin && launcher.ProcessId(account.Id) is not null)
            throw new InvalidOperationException("Already running. Use Rejoin game or Stop selected first.");
        account.Status = "Checking session"; RefreshStatus();
        if (account.Cookie.Length == 0) await SignInAsync(account, token);
        else
        {
            try
            {
                var user = await api.GetUserAsync(account.Cookie, token);
                if ((account.UserId > 0 && account.UserId != user.Id) ||
                    (account.UserId == 0 && !account.Username.Equals(user.Name, StringComparison.OrdinalIgnoreCase)))
                    throw new SessionExpiredException();
            }
            catch (SessionExpiredException) { account.Cookie = ""; await SignInAsync(account, token); }
        }
        // Fetch a fresh ticket before stopping a running player, so failed login does not close it.
        var ticket = await api.GetTicketAsync(account.Cookie, token);
        if (rejoin) await launcher.StopAsync(account.Id, token);
        account.Status = "Starting player…"; RefreshStatus();
        await launcher.LaunchAsync(account, target, client, ticket, token);
        account.Status = "Player opened";
        store.Save();
    }

    private async Task RunQueue(string verb, Func<Account, CancellationToken, Task> action, bool launch = false)
    {
        if (operation is not null) return;
        var selected = Selected();
        if (selected.Count == 0) { Error("Select one or more account rows first."); return; }
        operation = new CancellationTokenSource();
        foreach (var button in actions) button.Enabled = false;
        try { queueClient = launch ? ClientLauncher.FindClient(store.Data.RobloxClientPath) : null; }
        catch (Exception ex) { operation.Dispose(); operation = null; foreach (var button in actions) button.Enabled = true; Error(ex.Message); return; }
        game.Enabled = job.Enabled = false; cancel.Enabled = true;
        var errors = new List<string>(); var completed = 0; var cancelled = false;
        try
        {
            foreach (var account in selected)
            {
                if (operation.IsCancellationRequested) { cancelled = true; break; }
                status.Text = $"{verb}   {account.Username}   {completed + errors.Count + 1} of {selected.Count}";
                try { await action(account, operation.Token); completed++; }
                catch (OperationCanceledException) { account.Status = "Cancelled — check player if started"; cancelled = true; break; }
                catch (RobloxRateLimitException ex)
                { account.Status = "Roblox says wait before trying again"; errors.Add(account.Username + "  " + ex.Message); break; }
                catch (IOException ex)
                { account.Status = "Could not save   Check account"; errors.Add($"{account.Username}: {ex.Message}"); break; }
                catch (Exception ex)
                { account.Status = ex.Message; errors.Add($"{account.Username}: {ex.Message}"); }
                RefreshStatus();
            }
        }
        catch (OperationCanceledException) { cancelled = true; }
        finally
        {
            operation.Dispose(); operation = null;
            foreach (var button in actions) button.Enabled = true;
            game.Enabled = job.Enabled = true; cancel.Enabled = false; RefreshStatus();
            status.Text = $"{completed} done   {errors.Count} failed" + (cancelled ? "   Cancelled" : "");
            if (errors.Count > 0 && !pendingClose) Error(string.Join("\n\n", errors.Take(6)) + (errors.Count > 6 ? "\n\nSee account statuses for more failures." : ""));
            if (pendingClose) Close();
        }
    }

    private void Error(string message) => MessageBox.Show(this, Theme.Plain(message), "Grands Account Launcher", MessageBoxButtons.OK, MessageBoxIcon.Information);
    protected override void Dispose(bool disposing)
    {
        if (disposing && !disposed) { disposed = true; accountMenu.Dispose(); refresh.Dispose(); operation?.Cancel(); launcher.Dispose(); api.Dispose(); multi.Dispose(); }
        base.Dispose(disposing);
    }
}





