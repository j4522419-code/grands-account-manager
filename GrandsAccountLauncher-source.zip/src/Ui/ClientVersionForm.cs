using System.Diagnostics;
using GrandsAccountLauncher.Roblox;

namespace GrandsAccountLauncher.Ui;

internal sealed class ClientVersionForm : Form
{
    private sealed record Choice(string Path, string Label) { public override string ToString() => Label; }
    public string SelectedPath { get; private set; } = "";
    public ClientVersionForm(string savedPath)
    {
        Theme.Window(this); Text = "Roblox version"; ClientSize = new(620, 260);
        FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = false;
        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new(24), ColumnCount = 1, RowCount = 4 };
        layout.RowStyles.Add(new(SizeType.Absolute, 35)); layout.RowStyles.Add(new(SizeType.Absolute, 48));
        layout.RowStyles.Add(new(SizeType.Percent, 100)); layout.RowStyles.Add(new(SizeType.Absolute, 44));
        layout.Controls.Add(Theme.Label("Used for all accounts on the next join or rejoin"));
        var versions = new ComboBox { Dock = DockStyle.Top, DropDownStyle = ComboBoxStyle.DropDownList,
            BackColor = Theme.Surface, ForeColor = Theme.Text, FlatStyle = FlatStyle.Flat, DropDownWidth = 750 };
        var pathLabel = Theme.Label("", true); pathLabel.AutoSize = false; pathLabel.Dock = DockStyle.Fill;
        versions.Items.Add(new Choice("", "Automatic"));
        void AddPath(string path)
        {
            if (versions.Items.Cast<Choice>().Any(c => c.Path.Equals(path, StringComparison.OrdinalIgnoreCase))) return;
            string? version = null;
            try { if (File.Exists(path)) version = FileVersionInfo.GetVersionInfo(path).FileVersion; } catch (Exception) { }
            var folder = Path.GetFileName(Path.GetDirectoryName(path));
            versions.Items.Add(new Choice(path, (version is null ? "" : version + "   ") + folder + (File.Exists(path) ? "" : "   Missing")));
        }
        foreach (var path in ClientLauncher.InstalledClients()) AddPath(path);
        if (!string.IsNullOrWhiteSpace(savedPath)) AddPath(savedPath);
        versions.SelectedIndexChanged += (_, _) => pathLabel.Text = versions.SelectedItem is Choice c && c.Path.Length > 0
            ? c.Path : "Use the registered Roblox player or the newest installed version";
        versions.SelectedItem = versions.Items.Cast<Choice>().FirstOrDefault(c => c.Path.Equals(savedPath, StringComparison.OrdinalIgnoreCase)) ?? versions.Items[0];
        layout.Controls.Add(versions); layout.Controls.Add(pathLabel);
        var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill };
        buttons.Controls.Add(Theme.Button("Previous versions", (_, _) =>
        {
            using var dialog = new PreviousVersionsForm();
            if (dialog.ShowDialog(this) != DialogResult.OK || dialog.DownloadedPath is null) return;
            AddPath(dialog.DownloadedPath);
            versions.SelectedItem = versions.Items.Cast<Choice>().First(c => c.Path.Equals(dialog.DownloadedPath, StringComparison.OrdinalIgnoreCase));
        }));
        buttons.Controls.Add(Theme.Button("Browse", (_, _) =>
        {
            using var picker = new OpenFileDialog { Title = "Choose Roblox player", Filter = "Roblox player|RobloxPlayerBeta.exe", CheckFileExists = true };
            if (picker.ShowDialog(this) != DialogResult.OK) return;
            AddPath(picker.FileName); versions.SelectedItem = versions.Items.Cast<Choice>().First(c => c.Path.Equals(picker.FileName, StringComparison.OrdinalIgnoreCase));
        }));
        var save = Theme.Button("Save", (_, _) =>
        {
            var choice = (Choice)versions.SelectedItem!;
            try { if (choice.Path.Length > 0) ClientLauncher.FindClient(choice.Path); }
            catch (Exception ex) { MessageBox.Show(this, Theme.Plain(ex.Message), Text); return; }
            SelectedPath = choice.Path; DialogResult = DialogResult.OK;
        }, true);
        var cancel = Theme.Button("Cancel", (_, _) => Close()); cancel.DialogResult = DialogResult.Cancel;
        buttons.Controls.AddRange([save, cancel]); layout.Controls.Add(buttons); Controls.Add(layout);
        AcceptButton = save; CancelButton = cancel;
    }
}
