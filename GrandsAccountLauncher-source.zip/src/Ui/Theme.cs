namespace GrandsAccountLauncher.Ui;

internal static class Theme
{
    public static readonly Color Background = Color.Black;
    public static readonly Color Surface = Color.FromArgb(18, 18, 18);
    public static readonly Color Border = Color.FromArgb(64, 64, 64);
    public static readonly Color Text = Color.White;
    public static readonly Color Muted = Color.FromArgb(170, 170, 170);
    public static readonly Color Accent = Color.White;
    public static readonly Color Selection = Color.White;
    public static readonly Color SelectionText = Color.Black;
    public static readonly Color AlternateRow = Color.FromArgb(24, 24, 24);
    public static readonly Font Font = new("Segoe UI", 10);
    public static string Plain(string text) => System.Text.RegularExpressions.Regex.Replace(text, @"[^\p{L}\p{N}\s]", " ");
    public static void Window(Form form)
    {
        form.Font = Font; form.BackColor = Background; form.ForeColor = Text;
        form.AutoScaleMode = AutoScaleMode.Dpi;
        form.StartPosition = FormStartPosition.CenterScreen;
        var icon = Icon.ExtractAssociatedIcon(Environment.ProcessPath!);
        if (icon is not null) form.Icon = icon;
    }
    public static Button Button(string text, EventHandler action, bool primary = false)
    {
        var button = new Button { Text = text, AutoSize = true, MinimumSize = new(100, 38), Height = 38,
            Padding = new(12, 4, 12, 4), Margin = new(0, 0, 8, 0), FlatStyle = FlatStyle.Flat,
            BackColor = primary ? Accent : Surface, ForeColor = primary ? Background : Text, Cursor = Cursors.Hand };
        button.FlatAppearance.BorderColor = primary ? Accent : Border;
        button.Click += action;
        return button;
    }
    public static TextBox Input(string placeholder = "") => new() { PlaceholderText = placeholder,
        BackColor = Surface, ForeColor = Text, BorderStyle = BorderStyle.FixedSingle, Dock = DockStyle.Fill,
        Margin = new(0, 6, 0, 14) };
    public static Label Label(string text, bool muted = false) => new() { Text = text, AutoSize = true,
        ForeColor = muted ? Muted : Text, Margin = new(0, 0, 0, 6) };
}

