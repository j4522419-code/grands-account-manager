using GrandsAccountLauncher.Roblox;

namespace GrandsAccountLauncher.Ui;

internal sealed class PreviousVersionsForm : Form
{
    private readonly VersionDownloads downloads = new();
    private readonly ListBox list = new() { Dock = DockStyle.Fill, BackColor = Theme.Surface, ForeColor = Theme.Text, BorderStyle = BorderStyle.FixedSingle, HorizontalScrollbar = true };
    private readonly TextBox search = Theme.Input("Search version");
    private readonly Label message = Theme.Label("", true);
    private readonly ProgressBar progress = new() { Dock = DockStyle.Fill };
    private readonly Button download, refresh, cancel;
    private CancellationTokenSource? operation;
    private List<RemoteVersion> versions = [];
    private bool closing;
    public string? DownloadedPath { get; private set; }

    public PreviousVersionsForm(bool preview = false)
    {
        Theme.Window(this); Text = "Previous versions"; ClientSize = new(720, 500); MinimumSize = new(650, 420);
        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new(24), ColumnCount = 1, RowCount = 6 };
        layout.RowStyles.Add(new(SizeType.Absolute, 42)); layout.RowStyles.Add(new(SizeType.Percent, 100));
        layout.RowStyles.Add(new(SizeType.Absolute, 30)); layout.RowStyles.Add(new(SizeType.Absolute, 24));
        layout.RowStyles.Add(new(SizeType.Absolute, 36)); layout.RowStyles.Add(new(SizeType.Absolute, 44));
        layout.Controls.Add(search); layout.Controls.Add(list);
        layout.Controls.Add(Theme.Label("Old builds may no longer work with Roblox", true));
        layout.Controls.Add(progress); layout.Controls.Add(message);
        var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill };
        download = Theme.Button("Download", async (_, _) => await DownloadAsync(), true);
        refresh = Theme.Button("Refresh", async (_, _) => await LoadAsync());
        cancel = Theme.Button("Close", (_, _) => { if (operation is null) Close(); else operation.Cancel(); });
        buttons.Controls.AddRange([download, refresh, cancel]); layout.Controls.Add(buttons); Controls.Add(layout);
        search.TextChanged += (_, _) => Filter();
        list.SelectedIndexChanged += (_, _) => download.Enabled = operation is null && list.SelectedItem is RemoteVersion;
        download.Enabled = false;
        Shown += async (_, _) => { if (!preview) await LoadAsync(); };
        FormClosing += (_, e) => { if (operation is not null) { closing = true; operation.Cancel(); e.Cancel = true; } };
        FormClosed += (_, _) => downloads.Dispose();
    }

    private void Filter()
    {
        var id = (list.SelectedItem as RemoteVersion)?.Id;
        list.BeginUpdate(); list.Items.Clear();
        foreach (var version in versions.Where(v => v.ToString().Contains(search.Text.Trim(), StringComparison.OrdinalIgnoreCase))) list.Items.Add(version);
        list.SelectedItem = list.Items.Cast<RemoteVersion>().FirstOrDefault(v => v.Id == id);
        if (list.SelectedIndex < 0 && list.Items.Count > 0) list.SelectedIndex = 0;
        list.EndUpdate();
    }
    private async Task LoadAsync() => await RunAsync(async token =>
    {
        message.Text = "Loading versions";
        versions = await downloads.HistoryAsync(token); Filter();
        message.Text = $"{versions.Count} versions   Choose one to download";
    });
    private async Task DownloadAsync()
    {
        if (list.SelectedItem is not RemoteVersion version) return;
        await RunAsync(async token =>
        {
            DownloadedPath = await downloads.DownloadAsync(version.Id, VersionDownloads.InstallRoot,
                new Progress<DownloadProgress>(p => { if (IsDisposed) return; progress.Value = p.Percent; message.Text = $"{p.Message}   {p.Percent} percent"; }), token);
        });
        if (DownloadedPath is not null && !IsDisposed) DialogResult = DialogResult.OK;
    }
    private async Task RunAsync(Func<CancellationToken, Task> action)
    {
        if (operation is not null) return;
        operation = new(); search.Enabled = list.Enabled = refresh.Enabled = download.Enabled = false; cancel.Text = "Cancel";
        try { await action(operation.Token); }
        catch (OperationCanceledException) { message.Text = "Cancelled"; }
        catch (Exception ex) { message.Text = "Could not finish"; MessageBox.Show(this, Theme.Plain(ex.Message), Text); }
        finally
        {
            operation.Dispose(); operation = null;
            search.Enabled = list.Enabled = refresh.Enabled = true; download.Enabled = list.SelectedItem is RemoteVersion; cancel.Text = "Close";
            if (closing) Close();
        }
    }
}
