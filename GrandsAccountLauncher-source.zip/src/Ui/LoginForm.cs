using System.Text.Json;
using GrandsAccountLauncher.Roblox;
using GrandsAccountLauncher.Storage;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace GrandsAccountLauncher.Ui;

// The real Roblox login flow owns CAPTCHA/2FA. Challenges stay in that same browser session.
internal sealed class LoginForm : Form
{
    private readonly WebView2 browser = new() { Dock = DockStyle.Fill };
    private readonly Label message = new() { Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft };
    private readonly System.Windows.Forms.Timer poll = new() { Interval = 1200 };
    private readonly CancellationTokenSource lifetime = new();
    private readonly Account account;
    private readonly RobloxApi api;
    private bool checking, challengeShown;
    private DateTimeOffset started = DateTimeOffset.UtcNow, verifyAfter;
    private readonly InactivityWatchdog watchdog = new(DateTimeOffset.UtcNow);
    private int failures;
    private bool disposed;
    public string? SessionCookie { get; private set; }
    public RobloxUser? User { get; private set; }

    public LoginForm(Account account, RobloxApi api)
    {
        this.account = account; this.api = api;
        Theme.Window(this); Text = $"Sign in   {account.Username}";
        ClientSize = new(880, 720); MinimumSize = new(640, 560);
        var screen = Screen.FromPoint(Cursor.Position).WorkingArea;
        Size = new(Math.Min(Width, screen.Width - 30), Math.Min(Height, screen.Height - 30));
        StartPosition = FormStartPosition.Manual;
        Location = new(screen.Left + (screen.Width - Width) / 2, screen.Top + (screen.Height - Height) / 2);
        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 3, ColumnCount = 1 };
        layout.RowStyles.Add(new(SizeType.Absolute, 70)); layout.RowStyles.Add(new(SizeType.Absolute, 45)); layout.RowStyles.Add(new(SizeType.Percent, 100));
        message.Padding = new(16, 8, 16, 8);
        message.Text = $"Sign in as {account.Username}\nSolve any captcha here";
        layout.Controls.Add(message);
        var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, Padding = new(12, 0, 0, 0) };
        buttons.Controls.Add(Theme.Button("Reload", (_, _) =>
        {
            if (browser.CoreWebView2 is null) return;
            failures = 0; poll.Interval = 1200; started = DateTimeOffset.UtcNow;
            browser.CoreWebView2.Navigate("https://www.roblox.com/login");
            message.Text = "Reloading";
        }));
        layout.Controls.Add(buttons); layout.Controls.Add(browser); Controls.Add(layout);
        Shown += async (_, _) => await InitializeAsync();
        poll.Tick += async (_, _) => await CheckAsync();
        FormClosing += (_, _) => { poll.Stop(); lifetime.Cancel(); };
    }

    private async Task InitializeAsync()
    {
        try
        {
            browser.CreationProperties = new CoreWebView2CreationProperties
            {
                UserDataFolder = Path.Combine(AccountStore.DataDirectory, "Browser"),
                ProfileName = "Login_" + Guid.NewGuid().ToString("N"),
                IsInPrivateModeEnabled = true
            };
            await browser.EnsureCoreWebView2Async().WaitAsync(TimeSpan.FromSeconds(10), lifetime.Token);
            if (lifetime.IsCancellationRequested) return;
            var core = browser.CoreWebView2;
            core.Settings.IsPasswordAutosaveEnabled = false;
            core.Settings.IsGeneralAutofillEnabled = false;
            core.Settings.AreDevToolsEnabled = false;
            core.Settings.AreDefaultContextMenusEnabled = false;
            core.PermissionRequested += (_, e) => e.State = CoreWebView2PermissionState.Deny;
            core.DownloadStarting += (_, e) => e.Cancel = true;
            core.NavigationStarting += (_, e) => { if (!IsRobloxPage(e.Uri)) e.Cancel = true; else watchdog.Touch(DateTimeOffset.UtcNow); };
            core.NavigationCompleted += (_, e) => { if (!e.IsSuccess) message.Text = $"Page did not load   Press Reload"; };
            core.NewWindowRequested += (_, e) =>
            {
                e.Handled = true;
                if (IsRobloxPage(e.Uri)) core.Navigate(e.Uri);
            };
            core.Navigate("https://www.roblox.com/login");
            poll.Start();
        }
        catch (Exception) when (!lifetime.IsCancellationRequested)
        {
            message.Text = "Install Microsoft Edge WebView2 Runtime then try again";
        }
        catch (Exception) when (lifetime.IsCancellationRequested) { }
    }

    private static bool IsRobloxPage(string url) => Uri.TryCreate(url, UriKind.Absolute, out var uri) &&
        uri.Scheme == "https" && (uri.Host.Equals("roblox.com", StringComparison.OrdinalIgnoreCase) ||
        uri.Host.EndsWith(".roblox.com", StringComparison.OrdinalIgnoreCase));

    private async Task CheckAsync()
    {
        if (checking || lifetime.IsCancellationRequested || browser.CoreWebView2 is null) return;
        checking = true;
        try
        {
            var core = browser.CoreWebView2;
            if (!IsRobloxPage(core.Source))
            {
                if (watchdog.Tick(DateTimeOffset.UtcNow, "loading", false))
                { message.Text = "No response   Reloading"; core.Stop(); core.Navigate("https://www.roblox.com/login"); }
                return;
            }
            var state = JsonSerializer.Deserialize<FlowState>(await core.ExecuteScriptAsync(FlowScripts.Observe));
            if (lifetime.IsCancellationRequested || state is null) return;
            if (watchdog.Tick(DateTimeOffset.UtcNow, state.Progress, state.Challenge || state.UserActive || state.LoginRejected || state.RateLimited || DateTimeOffset.UtcNow < verifyAfter))
            {
                message.Text = "No response   Reloading";
                core.Stop(); core.Navigate("https://www.roblox.com/login"); return;
            }
            if (state.Challenge)
            {
                message.Text = "Solve the captcha here";
                if (!challengeShown) { challengeShown = true; WindowState = FormWindowState.Normal; BringToFront(); Activate(); }
            }
            else
            {
                challengeShown = false;
                if (state.LoginRejected) message.Text = "Check your username and password";
                else if (state.RateLimited) message.Text = "Roblox says wait before trying again";
                else
                {
                    var result = await core.ExecuteScriptAsync(FlowScripts.Login(account.Username, account.Password));
                    if (DateTimeOffset.UtcNow - started > TimeSpan.FromSeconds(45))
                        message.Text = result == "\"waiting\"" ? "The sign-in layout is not recognized. Sign in manually here, or use Reload." : "Waiting for Roblox";
                }
            }
            var cookies = await core.CookieManager.GetCookiesAsync("https://www.roblox.com/");
            var cookie = cookies.FirstOrDefault(c => c.Name == ".ROBLOSECURITY" &&
                (c.Domain.Equals(".roblox.com", StringComparison.OrdinalIgnoreCase) || c.Domain.Equals("roblox.com", StringComparison.OrdinalIgnoreCase) ||
                 c.Domain.Equals("www.roblox.com", StringComparison.OrdinalIgnoreCase)))?.Value;
            if (string.IsNullOrEmpty(cookie)) return;
            if (DateTimeOffset.UtcNow < verifyAfter) return;
            verifyAfter = DateTimeOffset.UtcNow.AddSeconds(3);
            using var verification = CancellationTokenSource.CreateLinkedTokenSource(lifetime.Token);
            verification.CancelAfter(TimeSpan.FromSeconds(10));
            var user = await api.GetUserAsync(cookie, verification.Token);
            if ((account.UserId > 0 && account.UserId != user.Id) ||
                (account.UserId == 0 && !user.Name.Equals(account.Username, StringComparison.OrdinalIgnoreCase)))
            {
                core.CookieManager.DeleteAllCookies();
                message.Text = $"Sign in as {account.Username}";
                core.Navigate("https://www.roblox.com/login"); return;
            }
            SessionCookie = cookie; User = user; poll.Stop(); DialogResult = DialogResult.OK;
        }
        catch (SessionExpiredException) { }
        catch (RobloxRateLimitException ex)
        {
            verifyAfter = RetryTime(ex.RetryAfter);
            message.Text = $"Roblox says wait   Retrying later";
        }
        catch (Exception) when (lifetime.IsCancellationRequested) { }
        catch (Exception)
        {
            failures++;
            if (failures >= 3)
            {
                poll.Interval = 6000;
                message.Text = "Waiting for Roblox   Close this window to cancel";
            }
        }
        finally { checking = false; }
    }

    private static DateTimeOffset RetryTime(string? value)
    {
        var now = DateTimeOffset.UtcNow;
        if (double.TryParse(value, System.Globalization.CultureInfo.InvariantCulture, out var seconds) && double.IsFinite(seconds))
            return now.AddSeconds(Math.Clamp(seconds, 60, 86400));
        if (DateTimeOffset.TryParse(value, out var date) && date > now) return date;
        return now.AddMinutes(1);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing && !disposed) { disposed = true; poll.Dispose(); lifetime.Cancel(); browser.Dispose(); lifetime.Dispose(); }
        base.Dispose(disposing);
    }
}


