namespace GrandsAccountLauncher.Ui;

internal sealed class AccountForm : Form
{
    private readonly TextBox username = Theme.Input("Roblox username");
    private readonly TextBox password = Theme.Input("Password");
    public Credentials? Result { get; private set; }
    public AccountForm(Account? account = null)
    {
        Theme.Window(this); Text = account is null ? "Add account" : "Edit password";
        ClientSize = new(440, 330); FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false; MinimizeBox = false;
        password.UseSystemPasswordChar = true;
        username.Text = account?.Username ?? "";
        username.ReadOnly = account is not null;
        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new(24), ColumnCount = 1, RowCount = 7 };
        layout.Controls.Add(Theme.Label("Username")); layout.Controls.Add(username);
        layout.Controls.Add(Theme.Label("Password")); layout.Controls.Add(password);
        layout.Controls.Add(Theme.Label("Saved encrypted", true));
        var buttons = new FlowLayoutPanel { AutoSize = true, Dock = DockStyle.Fill, Margin = new(0, 12, 0, 0) };
        var save = Theme.Button(account is null ? "Add account" : "Save password", (_, _) =>
        {
            if (!AccountImport.IsUsername(username.Text.Trim()) || password.Text.Length == 0)
            { MessageBox.Show(this, "Enter a username and password", Text); return; }
            Result = new(username.Text.Trim(), password.Text); DialogResult = DialogResult.OK;
        }, true);
        var cancel = Theme.Button("Cancel", (_, _) => Close()); cancel.DialogResult = DialogResult.Cancel;
        buttons.Controls.AddRange([save, cancel]); layout.Controls.Add(buttons); Controls.Add(layout);
        AcceptButton = save; CancelButton = cancel;
        FormClosed += (_, _) => password.Clear();
    }
}

