namespace GrandsAccountLauncher.Ui;

internal sealed class BulkImportForm : Form
{
    private readonly TextBox input = Theme.Input("");
    private readonly Label feedback = Theme.Label("Duplicates are skipped", true);
    public List<Credentials> Result { get; private set; } = [];
    public BulkImportForm(IEnumerable<string> existing)
    {
        Theme.Window(this); Text = "Bulk add accounts"; ClientSize = new(600, 510); MinimumSize = new(540, 440);
        var names = existing.ToArray();
        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new(24), ColumnCount = 1, RowCount = 5 };
        layout.RowStyles.Add(new(SizeType.AutoSize)); layout.RowStyles.Add(new(SizeType.AutoSize));
        layout.RowStyles.Add(new(SizeType.Percent, 100)); layout.RowStyles.Add(new(SizeType.Absolute, 68));
        layout.RowStyles.Add(new(SizeType.Absolute, 44));
        layout.Controls.Add(Theme.Label("One account per line"));
        layout.Controls.Add(Theme.Label("Put a colon between the username and password", true));
        input.Multiline = true; input.AcceptsReturn = true; input.WordWrap = false;
        input.ScrollBars = ScrollBars.Both; input.Font = new("Consolas", 11); input.MaxLength = 1_000_000;
        layout.Controls.Add(input); feedback.Dock = DockStyle.Fill; feedback.AutoSize = false; layout.Controls.Add(feedback);
        input.TextChanged += (_, _) =>
        {
            var parsed = AccountImport.Parse(input.Text, names);
            feedback.Text = $"{parsed.Accounts.Count} new   {parsed.Duplicates} duplicates   {parsed.Errors.Count} invalid\n" +
                (parsed.Errors.Select(Theme.Plain).FirstOrDefault() ?? "Saved encrypted");
        };
        var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill };
        buttons.Controls.Add(Theme.Button("Add accounts", (_, _) =>
        {
            var parsed = AccountImport.Parse(input.Text, names);
            if (parsed.Errors.Count > 0)
            { MessageBox.Show(this, string.Join("\n", parsed.Errors.Take(8).Select(Theme.Plain)) + "\n\nFix these lines first", "Check account list"); return; }
            if (parsed.Accounts.Count == 0) { feedback.Text = "No new accounts to add"; return; }
            Result = parsed.Accounts; DialogResult = DialogResult.OK;
        }, true));
        var cancel = Theme.Button("Cancel", (_, _) => Close()); cancel.DialogResult = DialogResult.Cancel;
        buttons.Controls.Add(cancel); layout.Controls.Add(buttons); Controls.Add(layout); CancelButton = cancel;
        FormClosed += (_, _) => input.Clear();
    }
}

