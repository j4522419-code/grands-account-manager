namespace GrandsAccountLauncher.Ui;

internal sealed class DisplayNamesForm : Form
{
    public string DisplayName { get; private set; } = "";
    public DisplayNamesForm(int count)
    {
        Theme.Window(this); Text = "Change display names";
        ClientSize = new(440, 220); FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false; MinimizeBox = false;
        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new(24), ColumnCount = 1 };
        layout.Controls.Add(Theme.Label($"Use this name for {count} selected accounts"));
        var input = Theme.Input("Display name"); layout.Controls.Add(input);
        var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true };
        var save = Theme.Button("Change names", (_, _) =>
        {
            if (string.IsNullOrWhiteSpace(input.Text)) return;
            DisplayName = input.Text.Trim(); DialogResult = DialogResult.OK;
        }, true);
        var cancel = Theme.Button("Cancel", (_, _) => Close()); cancel.DialogResult = DialogResult.Cancel;
        buttons.Controls.AddRange([save, cancel]); layout.Controls.Add(buttons); Controls.Add(layout);
        AcceptButton = save; CancelButton = cancel;
    }
}
