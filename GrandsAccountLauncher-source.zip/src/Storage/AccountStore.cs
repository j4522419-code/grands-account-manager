using System.Security.Cryptography;
using System.Text.Json;
using GrandsAccountLauncher.Security;


namespace GrandsAccountLauncher.Storage;

public sealed class AccountStore
{
    private static readonly byte[] Header = "GAL3"u8.ToArray();
    public static string DataDirectory => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "GrandsAccountLauncher");
    public string FilePath { get; }
    public LauncherData Data { get; private set; } = new();
    public AccountStore(string? path = null) => FilePath = path ?? Path.Combine(DataDirectory, "accounts.gal");

    public void Load()
    {
        if (!File.Exists(FilePath)) return;
        var envelope = JsonSerializer.Deserialize<Envelope>(File.ReadAllBytes(FilePath)) ?? throw new InvalidDataException("Invalid account file.");
        if (envelope.Format != "GAL3") throw new InvalidDataException("Unsupported account file format.");
        var key = WindowsProtection.Unprotect(Convert.FromBase64String(envelope.Key));
        byte[]? plain = null;
        try
        {
            var cipher = Convert.FromBase64String(envelope.Cipher);
            plain = new byte[cipher.Length];
            using var aes = new AesGcm(key, 16);
            aes.Decrypt(Convert.FromBase64String(envelope.Nonce), cipher, Convert.FromBase64String(envelope.Tag), plain, Header);
            var data = JsonSerializer.Deserialize<LauncherData>(plain) ?? throw new InvalidDataException("Invalid account contents.");
            if (data.Version != 3 || data.Accounts is null || data.Accounts.Any(a => a is null ||
                !AccountImport.IsUsername(a.Username) || !Guid.TryParseExact(a.Id, "N", out _) || a.Password is null || a.Cookie is null) ||
                data.Accounts.Select(a => a.Id).Distinct().Count() != data.Accounts.Count ||
                data.Accounts.Select(a => a.Username).Distinct(StringComparer.OrdinalIgnoreCase).Count() != data.Accounts.Count)
                throw new InvalidDataException("Invalid account records.");
            Data = data;
            foreach (var account in Data.Accounts) account.Status = account.Cookie.Length > 0 ? "Session saved" : "Needs sign-in";
        }
        finally
        {
            CryptographicOperations.ZeroMemory(key);
            if (plain is not null) CryptographicOperations.ZeroMemory(plain);
        }
    }

    internal List<Account> ImportAccounts(IReadOnlyList<Account> accounts)
    {
        AccountTransfer.ValidateAccounts(accounts);
        var names = Data.Accounts.Select(a => a.Username).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var userIds = Data.Accounts.Where(a => a.UserId > 0).Select(a => a.UserId).ToHashSet();
        var added = new List<Account>();
        foreach (var account in accounts)
        {
            if (names.Contains(account.Username) || account.UserId > 0 && userIds.Contains(account.UserId)) continue;
            names.Add(account.Username); if (account.UserId > 0) userIds.Add(account.UserId);
            added.Add(new Account { Username = account.Username, Password = account.Password, Cookie = account.Cookie,
                UserId = account.UserId, DisplayName = account.DisplayName, LastGame = account.LastGame, LastLaunchUtc = account.LastLaunchUtc,
                Status = account.Cookie.Length > 0 ? "Session saved" : "Needs sign in" });
        }
        if (added.Count == 0) return added;
        Data.Accounts.AddRange(added);
        try { Save(); }
        catch { foreach (var account in added) Data.Accounts.Remove(account); throw; }
        return added;
    }

    public void Save()
    {
        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(FilePath))!);
        var key = RandomNumberGenerator.GetBytes(32);
        var plain = JsonSerializer.SerializeToUtf8Bytes(Data);
        var temporary = FilePath + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            var nonce = RandomNumberGenerator.GetBytes(12);
            var tag = new byte[16];
            var cipher = new byte[plain.Length];
            using var aes = new AesGcm(key, 16);
            aes.Encrypt(nonce, plain, cipher, tag, Header);
            var envelope = new Envelope("GAL3", Convert.ToBase64String(WindowsProtection.Protect(key)),
                Convert.ToBase64String(nonce), Convert.ToBase64String(tag), Convert.ToBase64String(cipher));
            using (var stream = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None, 4096, FileOptions.WriteThrough))
            {
                JsonSerializer.Serialize(stream, envelope);
                stream.Flush(true);
            }
            if (File.Exists(FilePath)) File.Replace(temporary, FilePath, FilePath + ".bak", true);
            else File.Move(temporary, FilePath);
        }
        finally
        {
            CryptographicOperations.ZeroMemory(key);
            CryptographicOperations.ZeroMemory(plain);
            if (File.Exists(temporary)) File.Delete(temporary);
        }
    }

    private sealed record Envelope(string Format, string Key, string Nonce, string Tag, string Cipher);
}

