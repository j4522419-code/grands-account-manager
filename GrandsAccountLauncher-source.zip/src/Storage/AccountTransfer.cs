using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace GrandsAccountLauncher.Storage;

internal static class AccountTransfer
{
    internal const int MaximumBytes = 32 * 1024 * 1024;
    private const string Format = "GrandsAccounts1";
    private const int Iterations = 600_000;
    private sealed record Envelope(string Format, string Salt, string Nonce, string Tag, string Data);
    internal static bool IsPin(string pin) => pin.Length == 4 && pin.All(char.IsAsciiDigit);

    public static string Encrypt(IReadOnlyList<Account> accounts, string pin)
    {
        ValidatePin(pin); ValidateAccounts(accounts);
        var plain = JsonSerializer.SerializeToUtf8Bytes(accounts);
        if (plain.Length > MaximumBytes / 2) { CryptographicOperations.ZeroMemory(plain); throw new InvalidDataException("Too many accounts to export at once"); }
        var salt = RandomNumberGenerator.GetBytes(16); var nonce = RandomNumberGenerator.GetBytes(12);
        var key = Rfc2898DeriveBytes.Pbkdf2(pin, salt, Iterations, HashAlgorithmName.SHA256, 32);
        try
        {
            var data = new byte[plain.Length]; var tag = new byte[16];
            using var aes = new AesGcm(key, 16);
            aes.Encrypt(nonce, plain, data, tag, Encoding.UTF8.GetBytes(Format));
            return JsonSerializer.Serialize(new Envelope(Format, Convert.ToBase64String(salt), Convert.ToBase64String(nonce),
                Convert.ToBase64String(tag), Convert.ToBase64String(data)));
        }
        finally { CryptographicOperations.ZeroMemory(key); CryptographicOperations.ZeroMemory(plain); }
    }

    public static List<Account> Decrypt(string text, string pin)
    {
        ValidatePin(pin);
        if (text.Length > MaximumBytes) throw new InvalidDataException("This file is too large");
        byte[]? plain = null; byte[]? key = null;
        try
        {
            var envelope = JsonSerializer.Deserialize<Envelope>(text) ?? throw new InvalidDataException("Choose an exported account file");
            if (envelope.Format != Format) throw new InvalidDataException("Choose an exported account file");
            var salt = Convert.FromBase64String(envelope.Salt); var nonce = Convert.FromBase64String(envelope.Nonce);
            var tag = Convert.FromBase64String(envelope.Tag); var data = Convert.FromBase64String(envelope.Data);
            if (salt.Length != 16 || nonce.Length != 12 || tag.Length != 16 || data.Length > MaximumBytes / 2)
                throw new InvalidDataException("Invalid account file");
            key = Rfc2898DeriveBytes.Pbkdf2(pin, salt, Iterations, HashAlgorithmName.SHA256, 32);
            plain = new byte[data.Length];
            using var aes = new AesGcm(key, 16);
            aes.Decrypt(nonce, data, tag, plain, Encoding.UTF8.GetBytes(Format));
            var accounts = JsonSerializer.Deserialize<List<Account>>(plain) ?? throw new InvalidDataException("Invalid account file");
            ValidateAccounts(accounts);
            return accounts;
        }
        catch (CryptographicException) { throw new InvalidDataException("Wrong PIN or damaged account file"); }
        catch (Exception ex) when (ex is JsonException or FormatException or ArgumentNullException)
        { throw new InvalidDataException("Invalid account file"); }
        finally
        {
            if (key is not null) CryptographicOperations.ZeroMemory(key);
            if (plain is not null) CryptographicOperations.ZeroMemory(plain);
        }
    }

    public static void Write(string path, string encrypted)
    {
        if (!Path.GetExtension(path).Equals(".txt", StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Save the export as a txt file");
        var temporary = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            using (var file = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None, 4096, FileOptions.WriteThrough))
            { var bytes = Encoding.UTF8.GetBytes(encrypted); file.Write(bytes); file.Flush(true); }
            File.Move(temporary, path, overwrite: true);
        }
        finally { if (File.Exists(temporary)) File.Delete(temporary); }
    }
    public static string Read(string path)
    {
        using var file = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        if (file.Length > MaximumBytes) throw new InvalidDataException("This file is too large");
        using var reader = new StreamReader(file, Encoding.UTF8);
        return reader.ReadToEnd();
    }
    private static void ValidatePin(string pin)
    { if (!IsPin(pin)) throw new ArgumentException("Enter a four digit PIN"); }
    internal static void ValidateAccounts(IReadOnlyList<Account> accounts)
    {
        if (accounts.Count is < 1 or > 10000 || accounts.Any(a => a is null || a.Username is null || !AccountImport.IsUsername(a.Username) ||
            a.Password is null || a.Password.Length > 65536 || a.Cookie is null || a.Cookie.Length > 65536 || a.Cookie.Any(c => char.IsControl(c) || c == ';') ||
            a.UserId < 0 || a.DisplayName is null || a.DisplayName.Length > 1000 ||
            a.LastGame is { } game && (game.PlaceId <= 0 || game.JobId is not null && !Guid.TryParseExact(game.JobId, "D", out _))))
            throw new InvalidDataException("Invalid account records");
    }
}

internal enum CopyField { Username, Password, Cookie, Combo }
internal static class AccountCopy
{
    public static string Format(IEnumerable<Account> accounts, CopyField field) => string.Join(", ", accounts.Select(a => field switch
    {
        CopyField.Username => a.Username,
        CopyField.Password => a.Password,
        CopyField.Cookie => a.Cookie,
        CopyField.Combo => a.Username + ":" + a.Password,
        _ => throw new ArgumentOutOfRangeException(nameof(field))
    }));
}
