Grands Account Launcher

A simple black and white Roblox launcher for Windows

extract -win-x64.zip then run the .exe to use

Open GrandsAccountLauncher.exe
No app password is needed
Accounts are saved encrypted for your Windows user

Add account saves a username and password
Bulk add accepts one username and password per line with a colon between them
Passwords keep spaces and extra colons
Duplicate accounts are skipped

Select accounts then choose Display names to give them the same display name
Roblox decides whether the name can be used
If Roblox says to wait the remaining queue stops
You can retry later
The app changes your actual Roblox display name
It reads the name back from Roblox before showing success
If Roblox does not confirm the change the app tells you to check settings

Roblox version sets the player used for every account
Choose an installed version or browse to RobloxPlayerBeta.exe
Previous versions shows older builds
Choose a build then press Download
When it finishes press Save to use it for all accounts
You can search by version number or version ID
Downloads can be cancelled
Unavailable builds show an error
Automatic uses the registered player or the newest installed version
The choice stays saved when you close the launcher
It applies on the next join or rejoin
A missing version shows an error instead of switching to another version
Older versions still need to be accepted by Roblox

Join game opens a player for each selected account
Rejoin game uses each account last launched game
Enter a server ID if you want to request a specific server
An empty server field lets Roblox choose
There is no fixed delay between launches
Each launch waits for its player window

Sign in opens a separate window in the middle of your screen
Solve any captcha there
An unresponsive login page reloads after ten seconds
It waits while you solve a challenge or type
You can also sign in manually if the page layout changes

Stop selected closes players tracked for those accounts
Close all Roblox force closes every Roblox player including players opened outside this app
Keep the launcher open while using multiple players
After reopening the launcher close existing Roblox players before starting more

Saved accounts stay in the GrandsAccountLauncher folder under LocalAppData
Storage uses AES GCM encryption with a key protected by Windows DPAPI
The previous encrypted save is kept as a backup
Moving to another Windows user can make the saved file unreadable
There is no additional app password
Programs running as your Windows user can access data that user can decrypt

Account creation and groups are removed
Older saved data is preserved inside the encrypted file

Windows x64 and Microsoft Edge WebView2 Runtime are required
The download includes the NET runtime
Roblox must already be installed

To build install PowerShell 7 and NET SDK 10 then run build.ps1
Use the BrowserChecks switch to include the public login page check
Builds and source archives go into the release folder

Tests use fake sessions and local dummy players
Real sign in and game joining need testing with your accounts
See TEST-RESULTS.md for the checks performed

Roblox display name API
https://create.roblox.com/docs/cloud/reference/domains/users

The original MIT license and dependency notices are included



Previous build IDs come from the Roblox deployment history and the setup rbxcdn archive index
Packages are downloaded only from setup rbxcdn
The launcher checks package sizes and hashes before unpacking
Completed builds are stored in the launcher Versions folder under LocalAppData
Your normal Roblox installation is not replaced
Older builds may no longer join Roblox games

Version history sources
https://setup.rbxcdn.com/DeployHistory.txt
https://setup-rbxcdn.github.io/DeployHistory.txt

Package layout reference
https://github.com/bloxstraplabs/bloxstrap/wiki/A-deep-dive-on-how-the-Roblox-bootstrapper-works

Right click a selected account to copy usernames passwords cookies or combos
Hold Ctrl or Shift to select multiple rows
Copied values use a comma and space between accounts
Copy combo uses username then colon then password for each account

Export saves selected accounts
With no accounts selected Export saves all accounts
Choose a four digit PIN then save the encrypted txt file
Import opens that file and asks for the PIN
A wrong PIN or damaged file does not import any accounts
Accounts already saved here are skipped
Imports keep saved usernames passwords and cookies
Roblox may ask you to sign in again if a cookie has expired

Export encryption uses AES GCM with PBKDF2 SHA256 and a fresh salt and nonce
The PIN is not stored in the file
Exports can be imported on another computer
A four digit PIN has only ten thousand combinations so keep exported files private
Copied passwords and cookies stay on the Windows clipboard until replaced
