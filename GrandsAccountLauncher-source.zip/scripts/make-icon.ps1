$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$iconPath = Join-Path (Split-Path -Parent $PSScriptRoot) 'app.ico'
$images = @()
foreach ($size in @(32,64,256)) {
    $bitmap = [System.Drawing.Bitmap]::new($size,$size)
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    $graphics.SmoothingMode = 'AntiAlias'
    $graphics.Clear([System.Drawing.Color]::Black)
    $graphics.ScaleTransform($size/64.0,$size/64.0)
    $outline = [System.Drawing.Pen]::new([System.Drawing.Color]::FromArgb(160,160,160),3)
    $foreground = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::White)
    $graphics.DrawRectangle($outline,12,12,34,30)
    $graphics.FillRectangle([System.Drawing.Brushes]::Black,19,21,36,30)
    $graphics.DrawRectangle($outline,19,21,36,30)
    $points = [System.Drawing.PointF[]]@([System.Drawing.PointF]::new(30,28),[System.Drawing.PointF]::new(30,45),[System.Drawing.PointF]::new(44,36.5))
    $graphics.FillPolygon($foreground,$points)
    $memory = [System.IO.MemoryStream]::new()
    $bitmap.Save($memory,[System.Drawing.Imaging.ImageFormat]::Png)
    $images += @{ Size = $size; Data = $memory.ToArray() }
    $memory.Dispose(); $graphics.Dispose(); $bitmap.Dispose(); $outline.Dispose(); $foreground.Dispose()
}
$writer = [System.IO.BinaryWriter]::new([System.IO.File]::Create($iconPath))
try {
    $writer.Write([UInt16]0); $writer.Write([UInt16]1); $writer.Write([UInt16]$images.Count)
    $offset = 6 + 16*$images.Count
    foreach ($entry in $images) {
        $dimension = if ($entry.Size -eq 256) { 0 } else { $entry.Size }
        $writer.Write([byte]$dimension); $writer.Write([byte]$dimension); $writer.Write([UInt16]0)
        $writer.Write([UInt16]1); $writer.Write([UInt16]32); $writer.Write([UInt32]$entry.Data.Length); $writer.Write([UInt32]$offset)
        $offset += $entry.Data.Length
    }
    foreach ($entry in $images) { $writer.Write([byte[]]$entry.Data) }
} finally { $writer.Dispose() }
