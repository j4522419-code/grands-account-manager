$ErrorActionPreference = 'Stop'
$projectPath = Split-Path -Parent $PSScriptRoot
Add-Type -AssemblyName System.IO.Compression.FileSystem
function New-SourceArchive {
    $archivePath = Join-Path $projectPath 'release/GrandsAccountLauncher-source.zip'
    $stream = [System.IO.File]::Open($archivePath, [System.IO.FileMode]::Create)
    $zip = [System.IO.Compression.ZipArchive]::new($stream, [System.IO.Compression.ZipArchiveMode]::Create)
    try {
        # Explicit source allowlist excludes credentials, caches, and build outputs.
        $paths = @('src','scripts','licenses','tests/Program.cs','tests/DisplayNameTests.cs','tests/Launcher.Tests.csproj','tests/packages.lock.json',
            'GrandsAccountLauncher.csproj','global.json','Directory.Build.props','NuGet.Config','packages.lock.json',
            'app.ico','.gitignore','README.md','LICENSE','TEST-RESULTS.md','build.ps1')
        foreach ($relative in $paths) {
            $item = Get-Item -LiteralPath (Join-Path $projectPath $relative)
            $files = if ($item.PSIsContainer) { Get-ChildItem -LiteralPath $item.FullName -File -Recurse } else { @($item) }
            foreach ($file in $files) {
                $entryName = [System.IO.Path]::GetRelativePath($projectPath, $file.FullName).Replace('\','/')
                [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $file.FullName, $entryName) | Out-Null
            }
        }
    } finally { $zip.Dispose(); $stream.Dispose() }
}
New-SourceArchive
Compress-Archive -Path (Join-Path $projectPath 'release/app/*') -DestinationPath (Join-Path $projectPath 'release/GrandsAccountLauncher-win-x64.zip') -Force
Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $projectPath 'release/GrandsAccountLauncher-win-x64.zip'),(Join-Path $projectPath 'release/GrandsAccountLauncher-source.zip') |
    ForEach-Object { "$($_.Hash)  $([System.IO.Path]::GetFileName($_.Path))" } | Set-Content -LiteralPath (Join-Path $projectPath 'release/SHA256SUMS.txt')

